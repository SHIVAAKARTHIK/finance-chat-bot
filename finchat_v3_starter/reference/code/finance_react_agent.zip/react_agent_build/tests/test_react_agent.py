"""Offline tests for the guarded ReAct agent (no Databricks, no Bedrock)."""
from __future__ import annotations

import itertools

import pytest

from react_agent import (
    AgentConfig, FinanceReactAgent, ModelTurn, QueryResult, TableCandidate, ToolCall, UserContext,
    ValueMatch, default_envelope, should_use_agent, verify_answer,
)
from react_agent.verifier import extract_numbers

USER = UserContext(user_id="TEST_standard", roles=("standard",), can_view_pii=False)

FYNAPSE_BY_SOURCE = QueryResult(
    kind="answer",
    columns=["SOURCE_SYSTEM", "line_count", "line_count_share_pct", "net_reporting_amount"],
    rows=[["NOVIDEA", 433, 52.998776, -0.08], ["ACCRUAL", 214, 26.193390, 0.0], ["Concur", 170, 20.807833, 0.0]],
    scope_label="All authorized entities", period_label="All periods",
    tables=["lakehouse_mvpai.silver.fact_fynapse_slr_journals"], sql_rendered="SELECT ... -- masked",
)
FINALIZED_FLAG = QueryResult(kind="answer", columns=["ACCOUNT_NUMBER", "IS_FINALIZED"], rows=[["103300", "False"]],
                             scope_label="Entity 100 - 100-Northwind", period_label="Feb 25",
                             tables=["lakehouse_mvpai.silver.adra_account_facts"])


class FakeSilver:
    def __init__(self, query_results: list[QueryResult]):
        self._results = iter(query_results)
        self.specs: list[dict] = []
        self.users: list[UserContext] = []

    def find_tables(self, question, user, limit=6):
        self.users.append(user)
        return [TableCandidate("lakehouse_mvpai.silver.fact_fynapse_slr_journals", "subledger", "fact",
                               "Fynapse subledger journal lines; one row per journal line", 3.0)]

    def get_table_page(self, table, user):
        return "# fact_fynapse_slr_journals\ngrain: JOURNAL_LINE_ID\nmeasures: REPORTING_AMOUNT"

    def lookup_values(self, kind, text, user, table=None, column=None):
        return [ValueMatch(kind, "UK03", "UK03")]

    def query(self, spec, user):
        self.specs.append(spec)
        self.users.append(user)
        return next(self._results)


class ScriptedModel:
    """Returns pre-scripted turns; records what it was sent."""

    def __init__(self, turns: list[ModelTurn]):
        self.turns = list(turns)
        self.calls: list[list[dict]] = []
        self._ids = itertools.count(1)

    def converse(self, system, messages, tools, max_tokens, temperature, timeout_s):
        self.calls.append([dict(m) for m in messages])
        if not self.turns:
            raise AssertionError("model called more times than scripted")
        return self.turns.pop(0)


def call(name, **inp):
    call.n = getattr(call, "n", 0) + 1
    return ToolCall(id=f"t{call.n}", name=name, input=inp)


SPEC = {"anchor": "fact_fynapse_slr_journals",
        "measures": [{"column": "JOURNAL_LINE_ID", "operation": "count_rows", "alias": "line_count"}],
        "dimensions": [{"column": "SOURCE_SYSTEM"}], "share_of_total": True}


def happy_turns(answer_text):
    return [
        ModelTurn(tool_calls=[call("find_tables", question="q")]),
        ModelTurn(tool_calls=[call("query_silver", spec=SPEC)]),
        ModelTurn(tool_calls=[call("final_answer", kind="answer", answer_text=answer_text, result_ids=["r1"])]),
    ]


# ---------------------------------------------------------------- loop behaviour
def test_happy_path_verified_answer():
    text = ("Of 817 Fynapse journal lines, NOVIDEA has 433 (53.0%), ACCRUAL 214 (26.2%) and Concur 170 "
            "(20.8%). The net reporting amount is -0.08.")
    silver = FakeSilver([FYNAPSE_BY_SOURCE])
    agent = FinanceReactAgent(ScriptedModel(happy_turns(text)), silver)
    # 817 is not a cell but a column total computed by the verifier -> accepted
    res = agent.run("How concentrated are Fynapse lines by source system?", USER)
    assert res.kind == "answer" and res.verification == "verified", res.problems


def test_answer_with_only_cell_numbers_is_verified():
    text = "NOVIDEA has 433 lines (53.0%), ACCRUAL 214 (26.2%) and Concur 170 (20.8%); net amount -0.08."
    agent = FinanceReactAgent(ScriptedModel(happy_turns(text)), FakeSilver([FYNAPSE_BY_SOURCE]))
    res = agent.run("Fynapse lines by source system?", USER)
    assert res.kind == "answer" and res.verification == "verified"
    assert res.cited == ["r1"]
    env = default_envelope(res)
    assert env["result_table"]["rows"][0][0] == "NOVIDEA"
    assert env["tables"] == ["lakehouse_mvpai.silver.fact_fynapse_slr_journals"]
    assert [s["tool"] for s in env["agent_trace"]] == ["find_tables", "query_silver"]


def test_invented_number_triggers_repair_then_fallback():
    bad = "NOVIDEA has 500 lines."
    turns = happy_turns(bad) + [ModelTurn(tool_calls=[call("final_answer", kind="answer",
                                                            answer_text="NOVIDEA has 999 lines.", result_ids=["r1"])])]
    agent = FinanceReactAgent(ScriptedModel(turns), FakeSilver([FYNAPSE_BY_SOURCE]), config=AgentConfig(repair_attempts=1))
    res = agent.run("Fynapse lines by source?", USER)
    assert res.verification == "fallback"
    assert "433" in res.text and "500" not in res.text and "999" not in res.text
    assert res.problems


def test_repair_succeeds():
    turns = happy_turns("NOVIDEA has 500 lines.") + [ModelTurn(tool_calls=[call(
        "final_answer", kind="answer", answer_text="NOVIDEA has 433 lines.", result_ids=["r1"])])]
    model = ScriptedModel(turns)
    res = FinanceReactAgent(model, FakeSilver([FYNAPSE_BY_SOURCE])).run("q", USER)
    assert res.verification == "verified" and res.text == "NOVIDEA has 433 lines."
    # the model was told why: last message is a toolResult with verification_failed
    last = model.calls[-1][-1]["content"]
    assert any(b.get("toolResult", {}).get("content", [{}])[0].get("json", {}).get("error") == "verification_failed"
               for b in last)


def test_boolean_flag_needs_negation():
    turns = [ModelTurn(tool_calls=[call("query_silver", spec=SPEC)]),
             ModelTurn(tool_calls=[call("final_answer", kind="answer",
                                        answer_text="Account 103300 is finalized for 100-Northwind in Feb 25.",
                                        result_ids=["r1"])])]
    res = FinanceReactAgent(ScriptedModel(turns), FakeSilver([FINALIZED_FLAG]),
                            config=AgentConfig(repair_attempts=0)).run("Is 103300 finalized?", USER)
    assert res.verification == "fallback"
    turns_ok = [ModelTurn(tool_calls=[call("query_silver", spec=SPEC)]),
                ModelTurn(tool_calls=[call("final_answer", kind="answer",
                                           answer_text="Account 103300 is not finalized for 100-Northwind in Feb 25.",
                                           result_ids=["r1"])])]
    res2 = FinanceReactAgent(ScriptedModel(turns_ok), FakeSilver([FINALIZED_FLAG])).run("Is 103300 finalized?", USER)
    assert res2.verification == "verified"


def test_tool_budget_enforced():
    many = [ModelTurn(tool_calls=[call("find_tables", question="q")]) for _ in range(5)]
    many.append(ModelTurn(tool_calls=[call("final_answer", kind="cannot_answer", answer_text="I could not find it.")]))
    res = FinanceReactAgent(ScriptedModel(many), FakeSilver([]),
                            config=AgentConfig(max_tool_calls=2, max_model_turns=10)).run("q", USER)
    assert res.tool_calls == 2
    assert res.kind == "cannot_answer"


def test_model_turn_cap_falls_back():
    loop = [ModelTurn(tool_calls=[call("find_tables", question="q")]) for _ in range(3)]
    res = FinanceReactAgent(ScriptedModel(loop), FakeSilver([]), config=AgentConfig(max_model_turns=3)).run("q", USER)
    assert res.stop_reason == "max_model_turns" and res.verification == "fallback"


def test_time_budget_falls_back_with_partial_result():
    t = {"now": 0.0}

    def clock():
        return t["now"]

    class SlowModel(ScriptedModel):
        def converse(self, *a, **k):
            t["now"] += 6.0
            return super().converse(*a, **k)

    turns = [ModelTurn(tool_calls=[call("query_silver", spec=SPEC)]),
             ModelTurn(tool_calls=[call("find_tables", question="more")])]
    res = FinanceReactAgent(SlowModel(turns), FakeSilver([FYNAPSE_BY_SOURCE]),
                            config=AgentConfig(time_budget_s=14, reserve_s=2), clock=clock).run("q", USER)
    assert res.stop_reason == "time_budget"
    assert res.kind == "answer" and res.verification == "fallback" and "NOVIDEA" in res.text


def test_model_error_is_safe():
    class Boom:
        def converse(self, *a, **k):
            raise TimeoutError("read timeout")

    res = FinanceReactAgent(Boom(), FakeSilver([])).run("q", USER)
    assert res.kind == "cannot_answer" and res.stop_reason == "model_error"


def test_plain_text_reply_gets_one_nudge():
    turns = [ModelTurn(text="The answer is 433."),
             ModelTurn(tool_calls=[call("final_answer", kind="clarify", answer_text="Which entity?",
                                        clarification="Which entity do you mean?")])]
    res = FinanceReactAgent(ScriptedModel(turns), FakeSilver([])).run("q", USER)
    assert res.kind == "clarify" and res.text == "Which entity do you mean?"


# ---------------------------------------------------------------- security
def test_model_cannot_set_scope_or_user():
    spec = dict(SPEC, allowed_entity_scopes=[{"engagement_key": "999"}], user="admin", sql="DROP TABLE x")
    turns = [ModelTurn(tool_calls=[call("query_silver", spec=spec)]),
             ModelTurn(tool_calls=[call("final_answer", kind="answer", answer_text="NOVIDEA has 433 lines.",
                                        result_ids=["r1"])])]
    silver = FakeSilver([FYNAPSE_BY_SOURCE])
    FinanceReactAgent(ScriptedModel(turns), silver).run("q", USER)
    sent = silver.specs[0]
    assert "allowed_entity_scopes" not in sent and "user" not in sent and "sql" not in sent
    assert all(u == USER for u in silver.users)


def test_unknown_tool_and_tool_exception_return_errors_to_model():
    class Exploding(FakeSilver):
        def get_table_page(self, table, user):
            raise RuntimeError("boom")

    turns = [ModelTurn(tool_calls=[call("drop_tables"), call("get_table_page", table="x")]),
             ModelTurn(tool_calls=[call("final_answer", kind="cannot_answer", answer_text="I could not read the table.")])]
    model = ScriptedModel(turns)
    res = FinanceReactAgent(model, Exploding([])).run("q", USER)
    assert res.kind == "cannot_answer"
    statuses = [s.status for s in res.trace]
    assert statuses == ["error", "error"]


def test_refusal_results_cannot_be_cited_as_answers():
    nf = QueryResult(kind="not_found", message="The period 'Mar 23' was not found.")
    turns = [ModelTurn(tool_calls=[call("query_silver", spec=SPEC)]),
             ModelTurn(tool_calls=[call("final_answer", kind="answer", answer_text="The balance is 1,000.",
                                        result_ids=["r1"])])]
    res = FinanceReactAgent(ScriptedModel(turns), FakeSilver([nf]), config=AgentConfig(repair_attempts=0)).run("q", USER)
    assert res.verification == "fallback" and "1,000" not in res.text and "Mar 23" in res.text


def test_kpi_tools_hidden_when_no_kpi_port():
    seen = {}

    class Recorder(ScriptedModel):
        def converse(self, system, messages, tools, *a, **k):
            seen["tools"] = {t["toolSpec"]["name"] for t in tools}
            return super().converse(system, messages, tools, *a, **k)

    model = Recorder([ModelTurn(tool_calls=[call("final_answer", kind="cannot_answer", answer_text="No data.")])])
    FinanceReactAgent(model, FakeSilver([])).run("q", USER)
    assert "find_kpis" not in seen["tools"] and "run_kpi" not in seen["tools"]
    assert {"find_tables", "query_silver", "final_answer"} <= seen["tools"]


# ---------------------------------------------------------------- verifier units
@pytest.mark.parametrize("text,ok", [
    ("The balance is 1,981,646.00.", True),
    ("The balance is about 1.98 million.", True),
    ("The balance is 2.1 million.", False),
    ("Share is 53.0%.", True),
    ("Share is 53%.", True),
    ("Share is 52.0%.", False),
    ("Net amount is -0.08.", True),
    ("Net debit of 0.08.", True),
])
def test_verifier_numbers(text, ok):
    r = QueryResult(kind="answer", columns=["balance", "share_pct", "net"], rows=[[1981646.00, 52.998, -0.08]])
    assert verify_answer(text, [r], "question about account 141111").ok is ok


def test_question_numbers_allowed():
    r = QueryResult(kind="answer", columns=["balance"], rows=[[1981646.0]])
    assert verify_answer("Account 141111 has a balance of 1,981,646.00 in 2025.", [r],
                         "What is the balance of account 141111 in February 2025?").ok


def test_extract_numbers_formats():
    vals = [str(n.value) for n in extract_numbers("433 lines, 1,234.50 total, (12.5) loss, 22.8 million, 26.2%")]
    assert vals[:3] == ["433", "1234.50", "-12.5"]
    assert "22800000.0" in vals or "22800000" in vals[3]


# ---------------------------------------------------------------- routing
def test_routing():
    assert should_use_agent("Why did unidentified balances go up?") is True
    assert should_use_agent("What is the balance of account 141111?") is False
    assert should_use_agent("x", fast_path_kind="pii_restricted") is False
    assert should_use_agent("x", fast_path_kind="clarify") is True
    assert should_use_agent("x", fast_path_kind="answer") is False
    assert should_use_agent("x", mode="off") is False


def test_total_that_is_not_a_column_sum_is_rejected():
    r = QueryResult(kind="answer", columns=["src", "lines"], rows=[["A", 433], ["B", 214]])
    assert verify_answer("647 lines in total.", [r], "q").ok
    assert not verify_answer("700 lines in total.", [r], "q").ok


def test_bedrock_client_parses_tool_use():
    from react_agent import BedrockConverseClient

    class FakeBoto:
        def converse(self, **kw):
            assert kw["toolConfig"]["tools"] and kw["system"][0]["text"] == "sys"
            return {"stopReason": "tool_use", "usage": {"inputTokens": 10, "outputTokens": 5},
                    "output": {"message": {"content": [
                        {"text": "thinking"},
                        {"toolUse": {"toolUseId": "abc", "name": "find_tables", "input": {"question": "q"}}}]}}}

    turn = BedrockConverseClient("model-x", client=FakeBoto()).converse("sys", [], [{"toolSpec": {}}], 100, 0, 5)
    assert turn.tool_calls[0].name == "find_tables" and turn.tool_calls[0].input == {"question": "q"}
    assert turn.input_tokens == 10 and turn.text == "thinking"
