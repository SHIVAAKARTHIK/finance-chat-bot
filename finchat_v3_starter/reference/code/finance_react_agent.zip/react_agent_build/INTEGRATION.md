# Finance Chat ReAct agent (guarded) - integration guide

A self-contained package. It reasons over your existing pipeline through **tools**; it never writes
SQL and never sees or sets user scope. Everything about correctness and security stays in your
existing code (picker, label cache, compiler, guard, PII masking, entity scope, KPI templates).

## 1. Copy

```
react_agent/            -> finance_intelligence/src/sdk_agent/graph_v2/react_agent/
tests/test_react_agent.py -> finance_intelligence/tests/unit/test_react_agent.py
```
Fix the test import if needed (`from react_agent import ...` -> `from sdk_agent.graph_v2.react_agent import ...`).
Run: `python -m pytest finance_intelligence/tests/unit/test_react_agent.py -W error -q` (27 tests, offline).

No new dependencies. `boto3` is imported only by `BedrockConverseClient` (you already use Bedrock).

## 2. The only code you write: two adapters (`adapters.py` next to the package)

| Port method | Wrap your existing code | Must guarantee |
|---|---|---|
| `SilverPort.find_tables(question, user)` | semantic_silver picker (enabled + authorized domains only) | returns `TableCandidate(table, domain, role, summary, score)` |
| `SilverPort.get_table_page(table, user)` | read `prompts/silver_tables/<table>.md` | empty string if table not authorized |
| `SilverPort.lookup_values(kind, text, user, table, column)` | label cache / resolver (entity, period, account, column values) | only values inside the user's scope |
| `SilverPort.query(spec, user)` | the existing path: spec validation -> resolve -> compile -> guard -> execute -> envelope | scope, approved joins, casts, PII masking, timeouts; map your result kinds to `QueryResult.kind` |
| `KpiPort.find_kpis(question, user)` | KPI catalogue search (same as planner candidates) | only KPIs visible to the role |
| `KpiPort.run_kpi(kpi_id, filters, user)` | existing KPI execution | same checks as the KPI route |

`UserContext` is built from the authenticated request (user id, roles, can_view_pii). Never from the model.

Result kind mapping (your envelope -> `QueryResult.kind`): answer, not_found, clarify, cannot_compare,
pii_restricted, access_denied, domain_not_enabled, timeout, error. Put your readable reason in `message`,
and fill `scope_label`, `period_label`, `tables`, `sql_rendered` (masked).

If your spec model has different field names, translate in `SilverPort.query` (e.g. `count_rows` ->
your row-count measure). Unknown fields must be rejected by your validator, as today.

## 3. Wire into the graph (hybrid)

```python
from sdk_agent.graph_v2.react_agent import (AgentConfig, BedrockConverseClient, FinanceReactAgent,
    default_envelope, load_system_prompt, make_agent_node, should_use_agent)

cfg = AgentConfig.from_env()   # FINANCE_AGENT_MODEL_ID, FINANCE_AGENT_TIME_BUDGET_S, ...
agent_factory = lambda: FinanceReactAgent(
    model=BedrockConverseClient(cfg.model_id, region_name=settings.aws_region),
    silver=SilverAdapter(...), kpi=KpiAdapter(...), config=cfg,
    system_prompt=load_system_prompt("finance_intelligence/prompts/silver_query_skill.md"))

react_node = make_agent_node(
    agent_factory,
    get_question=lambda s: s["context"]["query"],          # ORIGINAL user text
    get_user=lambda s: build_user_context(s),
    to_state_update=lambda s, r: map_to_envelope(s, default_envelope(r)),
)
```
Routing (in the gate after semantic_silver): call `should_use_agent(question, fast_path_kind, reason,
mode=settings.finance_agent_mode)`; route to `react_agent` when True. Modes: `off` (default until tested),
`hybrid`, `always`. Safety outcomes (access_denied, pii_restricted, domain_not_enabled, cannot_compare)
are never retried by the agent.

## 4. Config (.env)

```
FINANCE_AGENT_MODE=off            # off | hybrid | always
FINANCE_AGENT_MODEL_ID=<Claude model / inference profile id from your Bedrock console>
FINANCE_AGENT_TIME_BUDGET_S=15
FINANCE_AGENT_MAX_TOOL_CALLS=6
```
The client uses `toolChoice: any` (the model must always call a tool). Use a Claude model on Bedrock;
some other models do not support it.

## 5. What the agent guarantees

- Numbers: every number in the final answer must appear in a cited result, the question, or be a column
  total of a cited result. Rounding only to the precision shown. Otherwise one repair, then a
  deterministic fallback built from the rows.
- Flags: a single False/No result must be stated with a negation.
- Budget: max tool calls, max model turns, time budget with reserve; on any limit or model error it
  returns the best verified/fallback answer, never an exception.
- Security: forbidden keys (user, scope, roles, sql, ...) are stripped from every tool input; user and
  scope are bound by the host. Tool results are passed as JSON data.
- Audit: `agent_trace` (tool, status, ms, result id) + tables + masked SQL for every cited result.
  Store it in the history row (e.g. the plan/explanation column).

## 6. Test plan (you run, live)

1. `FINANCE_AGENT_MODE=always` + question bank via the API path -> scorecard. Compare with the fast path.
2. Then `hybrid`: the scorecard must have wrong answers <= fast path and coverage >= fast path.
3. Watch p90 latency (target < 15 s for agent questions) and tokens per question.
4. ADRA silver golden must stay 12/12 in every mode.
