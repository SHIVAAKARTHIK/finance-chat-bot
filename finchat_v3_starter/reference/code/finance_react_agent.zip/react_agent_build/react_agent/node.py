"""LangGraph node wrapper. Keeps graph wiring in one small place.

The host supplies three callables, so this file needs no knowledge of the graph's state shape:
  get_question(state) -> str                 (the user's ORIGINAL question)
  get_user(state) -> UserContext             (from the authenticated request)
  to_state_update(state, AgentResult) -> dict (map onto the existing answer envelope fields)
Optionally get_context_note(state) -> str for follow-up context (entity/period from earlier turns).
"""
from __future__ import annotations

from typing import Any, Callable

from .agent import AgentResult, FinanceReactAgent
from .ports import UserContext


def make_agent_node(
    agent_factory: Callable[[], FinanceReactAgent],
    get_question: Callable[[dict[str, Any]], str],
    get_user: Callable[[dict[str, Any]], UserContext],
    to_state_update: Callable[[dict[str, Any], AgentResult], dict[str, Any]],
    get_context_note: Callable[[dict[str, Any]], str] | None = None,
) -> Callable[[dict[str, Any]], dict[str, Any]]:
    def react_agent_node(state: dict[str, Any]) -> dict[str, Any]:
        agent = agent_factory()
        note = get_context_note(state) if get_context_note else ""
        result = agent.run(get_question(state), get_user(state), context_note=note)
        return to_state_update(state, result)

    react_agent_node.__name__ = "react_agent"
    return react_agent_node


def default_envelope(result: AgentResult) -> dict[str, Any]:
    """A neutral dict the host can map to its answer envelope / history row."""
    cited = [result.results[r] for r in (result.cited or list(result.results))]
    last = next((r for r in reversed(cited) if r.kind == "answer"), None)
    return {
        "kind": result.kind,
        "answer_text": result.text,
        "verification": result.verification,  # verified | fallback | unverified_refusal
        "trust_label": "Unverified",
        "tables": result.tables,
        "sql_rendered": result.sql_rendered,
        "result_table": ({"columns": last.columns, "rows": last.rows} if last else None),
        "scope_label": last.scope_label if last else "",
        "period_label": last.period_label if last else "",
        "agent_trace": [
            {"step": s.step, "tool": s.tool, "status": s.status, "ms": s.ms, "result_id": s.result_id}
            for s in result.trace
        ],
        "model_turns": result.model_turns,
        "tool_calls": result.tool_calls,
        "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
        "elapsed_ms": result.elapsed_ms,
        "stop_reason": result.stop_reason,
        "problems": result.problems,
    }
