"""Agent configuration. Defaults are conservative; override from settings/env in the host."""
from __future__ import annotations

import os
from dataclasses import dataclass


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass
class AgentConfig:
    # Reasoning model (Bedrock model id or inference profile). Copy from your Bedrock console.
    model_id: str = ""
    max_tool_calls: int = 6  # total tool calls per question (excluding final_answer)
    max_model_turns: int = 6
    time_budget_s: float = 15.0  # whole agent run
    reserve_s: float = 2.0  # stop calling tools when less than this remains
    model_timeout_s: float = 8.0
    max_rows_to_model: int = 40  # rows of each result shown to the model
    max_page_chars: int = 4000  # table page size shown to the model
    max_tokens: int = 1500
    temperature: float = 0.0
    repair_attempts: int = 1  # retries when the final answer fails verification

    @classmethod
    def from_env(cls) -> "AgentConfig":
        return cls(
            model_id=os.environ.get("FINANCE_AGENT_MODEL_ID", ""),
            max_tool_calls=_env_int("FINANCE_AGENT_MAX_TOOL_CALLS", 6),
            max_model_turns=_env_int("FINANCE_AGENT_MAX_MODEL_TURNS", 6),
            time_budget_s=_env_float("FINANCE_AGENT_TIME_BUDGET_S", 15.0),
            model_timeout_s=_env_float("FINANCE_AGENT_MODEL_TIMEOUT_S", 8.0),
        )
