"""The ReAct loop: model -> tools -> model ... -> final_answer, under a step and time budget."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable

from .config import AgentConfig
from .model_client import ModelClient, ModelTurn
from .ports import KpiPort, QueryResult, SilverPort, UserContext
from .prompt import SYSTEM_PROMPT
from .tools import ToolDispatcher, TraceStep, tool_result_block, tool_specs
from .verifier import fallback_text, verify_answer


@dataclass
class AgentResult:
    kind: str  # answer | clarify | cannot_answer | timeout | error
    text: str
    verification: str  # verified | fallback | unverified_refusal
    results: dict[str, QueryResult] = field(default_factory=dict)
    cited: list[str] = field(default_factory=list)
    trace: list[TraceStep] = field(default_factory=list)
    model_turns: int = 0
    tool_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    elapsed_ms: float = 0.0
    stop_reason: str = ""
    problems: list[str] = field(default_factory=list)

    @property
    def tables(self) -> list[str]:
        seen: list[str] = []
        for rid in self.cited or list(self.results):
            for t in self.results[rid].tables:
                if t not in seen:
                    seen.append(t)
        return seen

    @property
    def sql_rendered(self) -> list[str]:
        return [self.results[r].sql_rendered for r in (self.cited or list(self.results)) if self.results[r].sql_rendered]


class FinanceReactAgent:
    def __init__(
        self,
        model: ModelClient,
        silver: SilverPort,
        kpi: KpiPort | None = None,
        config: AgentConfig | None = None,
        system_prompt: str = SYSTEM_PROMPT,
        clock: Callable[[], float] = time.monotonic,
    ):
        self.model = model
        self.silver = silver
        self.kpi = kpi
        self.config = config or AgentConfig()
        self.system_prompt = system_prompt
        self.clock = clock

    def run(self, question: str, user: UserContext, context_note: str = "") -> AgentResult:
        cfg = self.config
        start = self.clock()
        deadline = start + cfg.time_budget_s
        tools = tool_specs()
        if self.kpi is None:
            tools = [t for t in tools if t["toolSpec"]["name"] not in ("find_kpis", "run_kpi")]
        disp = ToolDispatcher(self.silver, self.kpi, user, cfg)
        user_text = question if not context_note else f"{question}\n\n(Conversation context: {context_note})"
        messages: list[dict[str, Any]] = [{"role": "user", "content": [{"text": user_text}]}]
        res = AgentResult(kind="error", text="", verification="unverified_refusal")
        repairs_left = cfg.repair_attempts
        step = 0

        def finish(kind: str, text: str, verification: str, stop: str, cited: list[str] | None = None,
                   problems: list[str] | None = None) -> AgentResult:
            res.kind, res.text, res.verification, res.stop_reason = kind, text, verification, stop
            res.cited = cited or []
            res.problems = problems or []
            res.results = disp.state.results
            res.trace = disp.state.trace
            res.tool_calls = disp.state.tool_calls
            res.elapsed_ms = round((self.clock() - start) * 1000, 1)
            return res

        def safe_fallback(stop: str, problems: list[str] | None = None) -> AgentResult:
            results = list(disp.state.results.values())
            has_answer = any(r.kind == "answer" for r in results)
            kind = "answer" if has_answer else ("timeout" if stop == "time_budget" else "cannot_answer")
            return finish(kind, fallback_text(results), "fallback", stop, problems=problems)

        while True:
            remaining = deadline - self.clock()
            if res.model_turns >= cfg.max_model_turns:
                return safe_fallback("max_model_turns")
            if remaining <= cfg.reserve_s:
                return safe_fallback("time_budget")
            try:
                turn: ModelTurn = self.model.converse(
                    self.system_prompt, messages, tools, cfg.max_tokens, cfg.temperature,
                    timeout_s=min(cfg.model_timeout_s, max(1.0, remaining - cfg.reserve_s / 2)),
                )
            except Exception as exc:  # model failure -> safe fallback, never an exception to the user
                return safe_fallback("model_error", [f"{type(exc).__name__}: {str(exc)[:200]}"])
            res.model_turns += 1
            res.input_tokens += turn.input_tokens
            res.output_tokens += turn.output_tokens
            assistant_content = turn.raw_content or (
                ([{"text": turn.text}] if turn.text else [])
                + [{"toolUse": {"toolUseId": c.id, "name": c.name, "input": c.input}} for c in turn.tool_calls]
            )
            if not turn.tool_calls:
                # Model answered in plain text instead of final_answer: ask once for final_answer.
                if turn.text and repairs_left > 0:
                    repairs_left -= 1
                    messages.append({"role": "assistant", "content": assistant_content or [{"text": turn.text}]})
                    messages.append({"role": "user", "content": [{"text": "Submit your answer with the final_answer tool."}]})
                    continue
                return safe_fallback("no_tool_call")
            messages.append({"role": "assistant", "content": assistant_content})

            result_blocks: list[dict[str, Any]] = []
            final_call = None
            for call in turn.tool_calls:
                if call.name == "final_answer":
                    final_call = call
                    continue
                step += 1
                if disp.state.tool_calls >= cfg.max_tool_calls:
                    result_blocks.append(tool_result_block(call.id, {"error": "tool_budget_exhausted",
                        "message": "No more tool calls. Answer now with final_answer."}, is_error=True))
                    continue
                if deadline - self.clock() <= cfg.reserve_s:
                    result_blocks.append(tool_result_block(call.id, {"error": "time_budget_exhausted",
                        "message": "Time is up. Answer now with final_answer."}, is_error=True))
                    continue
                disp.state.tool_calls += 1
                payload = disp.execute(call.name, call.input, step)
                result_blocks.append(tool_result_block(call.id, payload, is_error="error" in payload))

            if final_call is not None:
                fa = final_call.input or {}
                kind = str(fa.get("kind", "answer"))
                text = str(fa.get("answer_text", "")).strip()
                cited_ids = [r for r in (fa.get("result_ids") or []) if r in disp.state.results]
                if kind == "clarify":
                    clar = str(fa.get("clarification") or text).strip()
                    return finish("clarify", clar, "unverified_refusal", "final_answer")
                if kind == "cannot_answer":
                    v = verify_answer(text, [disp.state.results[r] for r in cited_ids], question)
                    if v.ok:
                        return finish("cannot_answer", text, "unverified_refusal", "final_answer", cited_ids)
                    return safe_fallback("cannot_answer_unverified", v.problems)
                if not cited_ids:
                    cited_ids = [rid for rid, r in disp.state.results.items() if r.kind == "answer"]
                v = verify_answer(text, [disp.state.results[r] for r in cited_ids], question)
                if v.ok and text:
                    return finish("answer", text, "verified", "final_answer", cited_ids)
                if repairs_left > 0 and deadline - self.clock() > cfg.reserve_s:
                    repairs_left -= 1
                    result_blocks.append(tool_result_block(final_call.id, {
                        "error": "verification_failed",
                        "problems": v.problems or ["empty answer"],
                        "message": "Rewrite final_answer using only numbers and labels from the cited results."},
                        is_error=True))
                    messages.append({"role": "user", "content": result_blocks})
                    continue
                return safe_fallback("verification_failed", v.problems)

            messages.append({"role": "user", "content": result_blocks})
