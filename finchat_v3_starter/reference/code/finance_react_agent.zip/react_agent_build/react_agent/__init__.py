"""Finance Chat ReAct agent (guarded): reasons over existing tools, never writes SQL."""
from .agent import AgentResult, FinanceReactAgent
from .config import AgentConfig
from .model_client import BedrockConverseClient, ModelClient, ModelTurn, ToolCall
from .node import default_envelope, make_agent_node
from .ports import KpiCandidate, KpiPort, QueryResult, SilverPort, TableCandidate, UserContext, ValueMatch
from .prompt import SYSTEM_PROMPT, load_system_prompt
from .routing import looks_complex, should_use_agent
from .verifier import fallback_text, verify_answer

__all__ = [
    "AgentConfig", "AgentResult", "BedrockConverseClient", "FinanceReactAgent", "KpiCandidate", "KpiPort",
    "ModelClient", "ModelTurn", "QueryResult", "SYSTEM_PROMPT", "SilverPort", "TableCandidate", "ToolCall",
    "UserContext", "ValueMatch", "default_envelope", "fallback_text", "load_system_prompt", "looks_complex",
    "make_agent_node", "should_use_agent", "verify_answer",
]
