"""Tool definitions (Bedrock Converse toolSpec format) and the dispatcher.

The model can only: find tables, read table pages, look up values, run a guarded silver
query (spec, never SQL), find/run KPIs, and submit a final answer. Identity, scope and PII
permission are bound by the host into the dispatcher and are never accepted from the model.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from typing import Any

from .config import AgentConfig
from .ports import KpiPort, QueryResult, SilverPort, UserContext

# Keys the model must never be able to pass (defence in depth; schemas don't offer them either).
FORBIDDEN_KEYS = {
    "user", "user_id", "role", "roles", "scope", "scopes", "allowed_entity_scopes", "domain_scopes",
    "can_view_pii", "pii", "sql", "raw_sql", "query_sql", "access", "rbac",
}

_SPEC_SCHEMA: dict[str, Any] = {
    "type": "object",
    "description": (
        "Semantic-silver query spec. Use only tables, columns and join recipe ids seen in "
        "find_tables/get_table_page. Copy entity, period and account text from the question into "
        "entity_mention / period_mention / account; never put them in filters."
    ),
    "properties": {
        "anchor": {"type": "string", "description": "Fact table that holds the measured thing."},
        "measures": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "table": {"type": "string"},
                    "column": {"type": "string"},
                    "alias": {"type": "string"},
                    "operation": {
                        "type": "string",
                        "enum": ["value", "sum", "count", "count_rows", "count_distinct", "max", "min", "avg",
                                 "count_true", "count_false"],
                    },
                },
                "required": ["column", "operation"],
            },
        },
        "dimensions": {"type": "array", "items": {"type": "object"}},
        "join_recipe_ids": {"type": "array", "items": {"type": "string"}},
        "filters": {"type": "array", "items": {"type": "object"}},
        "entity_mention": {"type": ["string", "null"]},
        "account": {"type": ["string", "null"]},
        "period_mention": {"type": ["string", "null"]},
        "period_policy": {"type": "string", "enum": ["explicit", "latest", "all", "compare_previous"]},
        "order_by": {"type": ["string", "null"]},
        "descending": {"type": "boolean"},
        "limit": {"type": ["integer", "null"]},
        "share_of_total": {"type": "boolean", "description": "Also return each row's share of the total."},
    },
    "required": ["anchor", "measures"],
}


def tool_specs() -> list[dict[str, Any]]:
    def spec(name: str, description: str, schema: dict[str, Any]) -> dict[str, Any]:
        return {"toolSpec": {"name": name, "description": description, "inputSchema": {"json": schema}}}

    return [
        spec("find_kpis", "Find governed KPIs that may answer the question. Prefer a KPI when one fits exactly.",
             {"type": "object", "properties": {"question": {"type": "string"}}, "required": ["question"]}),
        spec("run_kpi", "Run a governed KPI by id with optional filters (entity, period).",
             {"type": "object",
              "properties": {"kpi_id": {"type": "string"}, "filters": {"type": "object"}},
              "required": ["kpi_id"]}),
        spec("find_tables", "Find silver tables (with domain, fact/dim role, one-line summary) for a question.",
             {"type": "object", "properties": {"question": {"type": "string"}}, "required": ["question"]}),
        spec("get_table_page", "Read a table's page: columns, meanings, status values, approved joins, "
             "entity/period binding.",
             {"type": "object", "properties": {"table": {"type": "string"}}, "required": ["table"]}),
        spec("lookup_values", "Check how an entity, period, account or column value is written in the data.",
             {"type": "object",
              "properties": {
                  "kind": {"type": "string", "enum": ["entity", "period", "account", "column_value"]},
                  "text": {"type": "string"},
                  "table": {"type": "string"},
                  "column": {"type": "string"}},
              "required": ["kind", "text"]}),
        spec("query_silver", "Run one guarded semantic-silver query from a spec. Returns rows or a reason.",
             {"type": "object", "properties": {"spec": _SPEC_SCHEMA}, "required": ["spec"]}),
        spec("final_answer", "Submit the final answer. Every number in answer_text must come from the "
             "results listed in result_ids.",
             {"type": "object",
              "properties": {
                  "kind": {"type": "string", "enum": ["answer", "clarify", "cannot_answer"]},
                  "answer_text": {"type": "string", "description": "1-4 plain business sentences."},
                  "result_ids": {"type": "array", "items": {"type": "string"}},
                  "clarification": {"type": "string"}},
              "required": ["kind", "answer_text"]}),
    ]


@dataclass
class TraceStep:
    step: int
    tool: str
    input: dict[str, Any]
    status: str
    ms: float
    result_id: str | None = None
    note: str = ""


@dataclass
class ToolState:
    results: dict[str, QueryResult] = field(default_factory=dict)
    trace: list[TraceStep] = field(default_factory=list)
    tool_calls: int = 0


def _strip_forbidden(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _strip_forbidden(v) for k, v in obj.items() if str(k).lower() not in FORBIDDEN_KEYS}
    if isinstance(obj, list):
        return [_strip_forbidden(v) for v in obj]
    return obj


def _jsonable(v: Any) -> Any:
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    return str(v)


class ToolDispatcher:
    """Executes tool calls against the ports with the host-bound user."""

    def __init__(self, silver: SilverPort, kpi: KpiPort | None, user: UserContext, config: AgentConfig):
        self.silver = silver
        self.kpi = kpi
        self.user = user
        self.config = config
        self.state = ToolState()

    # ---- helpers -------------------------------------------------------------------------
    def _result_payload(self, rid: str, r: QueryResult) -> dict[str, Any]:
        rows = r.rows[: self.config.max_rows_to_model]
        return {
            "result_id": rid,
            "kind": r.kind,
            "source": r.source,
            "columns": r.columns,
            "rows": [[_jsonable(c) for c in row] for row in rows],
            "row_count": len(r.rows),
            "truncated": len(r.rows) > len(rows),
            "message": r.message,
            "scope": r.scope_label,
            "period": r.period_label,
            "tables": r.tables,
        }

    def _store(self, r: QueryResult) -> str:
        rid = f"r{len(self.state.results) + 1}"
        self.state.results[rid] = r
        return rid

    # ---- dispatch ------------------------------------------------------------------------
    def execute(self, name: str, raw_input: dict[str, Any], step: int) -> dict[str, Any]:
        t0 = time.perf_counter()
        args = _strip_forbidden(raw_input if isinstance(raw_input, dict) else {})
        rid = None
        try:
            if name == "find_tables":
                cands = self.silver.find_tables(str(args.get("question", "")), self.user)
                out: dict[str, Any] = {"tables": [asdict(c) for c in cands]}
            elif name == "get_table_page":
                page = self.silver.get_table_page(str(args.get("table", "")), self.user) or ""
                out = {"table": args.get("table"), "page": page[: self.config.max_page_chars],
                       "available": bool(page)}
            elif name == "lookup_values":
                matches = self.silver.lookup_values(
                    str(args.get("kind", "")), str(args.get("text", "")), self.user,
                    table=args.get("table"), column=args.get("column"))
                out = {"matches": [asdict(m) for m in matches]}
            elif name == "query_silver":
                spec = args.get("spec")
                if not isinstance(spec, dict):
                    raise ValueError("spec must be an object")
                r = self.silver.query(spec, self.user)
                rid = self._store(r)
                out = self._result_payload(rid, r)
            elif name == "find_kpis":
                if self.kpi is None:
                    out = {"kpis": [], "note": "KPI tools not available"}
                else:
                    out = {"kpis": [asdict(k) for k in self.kpi.find_kpis(str(args.get("question", "")), self.user)]}
            elif name == "run_kpi":
                if self.kpi is None:
                    raise ValueError("KPI tools not available")
                filters = args.get("filters") or {}
                if not isinstance(filters, dict):
                    raise ValueError("filters must be an object")
                r = self.kpi.run_kpi(str(args.get("kpi_id", "")), filters, self.user)
                rid = self._store(r)
                out = self._result_payload(rid, r)
            else:
                raise ValueError(f"unknown tool: {name}")
            status = "ok"
        except Exception as exc:  # tool errors go back to the model as data, never raised
            out = {"error": type(exc).__name__, "message": str(exc)[:300]}
            status = "error"
        self.state.trace.append(TraceStep(
            step=step, tool=name, input=args, status=status,
            ms=round((time.perf_counter() - t0) * 1000, 1), result_id=rid))
        return out


def tool_result_block(tool_use_id: str, payload: dict[str, Any], is_error: bool = False) -> dict[str, Any]:
    # Results are data. Wrapping as JSON keeps them separate from instructions.
    block: dict[str, Any] = {"toolResult": {"toolUseId": tool_use_id, "content": [{"json": payload}]}}
    if is_error:
        block["toolResult"]["status"] = "error"
    return block


def dumps_compact(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)
