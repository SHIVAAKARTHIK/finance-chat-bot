"""Deterministic checks on the agent's final answer, and the safe fallback text.

Rule: every number in the answer must be backed by a cell or label in the results the
answer cites, or appear in the user's question (account numbers, years, "top 5"). Rounding
is allowed only to the precision the answer shows. A single False/No flag must be stated
with a negation.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable

from .ports import QueryResult

_NUM_RE = re.compile(
    r"(?<![\w.])(?P<sign>[-−])?\(?(?P<num>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\)?"
    r"(?P<pct>\s?%)?(?:\s?(?P<scale>million|billion|thousand|mn|bn|m|k)\b)?",
    re.IGNORECASE,
)
_SCALES = {"thousand": 1_000, "k": 1_000, "million": 1_000_000, "mn": 1_000_000, "m": 1_000_000,
           "billion": 1_000_000_000, "bn": 1_000_000_000}
_NEGATION = re.compile(r"\b(not|no|isn't|hasn't|wasn't|aren't|haven't|never|yet to)\b", re.IGNORECASE)
_TRUE = {"true", "yes", "y", "1", "t"}
_FALSE = {"false", "no", "n", "0", "f"}


@dataclass
class FoundNumber:
    text: str
    value: Decimal
    decimals: int
    is_pct: bool


@dataclass
class VerifyResult:
    ok: bool
    problems: list[str] = field(default_factory=list)


def _to_decimal(s: str) -> Decimal | None:
    try:
        return Decimal(s.replace(",", ""))
    except (InvalidOperation, AttributeError):
        return None


def extract_numbers(text: str) -> list[FoundNumber]:
    found: list[FoundNumber] = []
    for m in _NUM_RE.finditer(text or ""):
        raw = m.group("num")
        val = _to_decimal(raw)
        if val is None:
            continue
        decimals = len(raw.split(".")[1]) if "." in raw else 0
        scale = (m.group("scale") or "").lower()
        if scale:
            val = val * _SCALES[scale]
            # "22.8 million" is precise to 0.1 million
            decimals = decimals - len(str(_SCALES[scale])) + 1
        if m.group("sign") or (m.group(0).startswith("(") and m.group(0).rstrip().endswith(")")):
            val = -val
        found.append(FoundNumber(text=m.group(0).strip(), value=val, decimals=decimals, is_pct=bool(m.group("pct"))))
    return found


def _cell_numbers(v: Any) -> list[Decimal]:
    if v is None or isinstance(v, bool):
        return []
    if isinstance(v, (int, float, Decimal)):
        try:
            return [Decimal(str(v))]
        except InvalidOperation:
            return []
    return [n.value for n in extract_numbers(str(v))]


def allowed_numbers(results: Iterable[QueryResult], question: str) -> list[Decimal]:
    allowed: list[Decimal] = []
    for r in results:
        pct_cols = {i for i, c in enumerate(r.columns)
                    if any(k in c.lower() for k in ("pct", "percent", "share", "ratio", "rate"))}
        for row in r.rows:
            for i, cell in enumerate(row):
                nums = _cell_numbers(cell)
                allowed.extend(nums)
                if i in pct_cols:  # ratio 0.53 may be shown as 53%
                    allowed.extend(x * 100 for x in nums if abs(x) <= 1)
        for label in (r.scope_label, r.period_label):
            allowed.extend(n.value for n in extract_numbers(label))
        allowed.append(Decimal(len(r.rows)))  # "3 accounts" when 3 rows are listed
        if len(r.rows) > 1:  # totals the answer may state ("817 lines in total"), computed here
            for i in range(len(r.columns)):
                col = [_cell_numbers(row[i]) for row in r.rows if i < len(row)]
                if col and all(len(c) == 1 for c in col):
                    allowed.append(sum((c[0] for c in col), Decimal(0)))
    allowed.extend(n.value for n in extract_numbers(question))
    return allowed


def _matches(n: FoundNumber, allowed: list[Decimal]) -> bool:
    # Tolerance: half a unit of the last digit the answer shows (honest rounding only).
    tol = Decimal(5) * (Decimal(10) ** (-(n.decimals + 1)))
    for a in allowed:
        if abs(n.value - a) <= tol:
            return True
        # sign may be expressed in words ("a net debit of 455,376.16")
        if abs(abs(n.value) - abs(a)) <= tol:
            return True
    return False


def verify_answer(answer_text: str, cited: list[QueryResult], question: str) -> VerifyResult:
    problems: list[str] = []
    if not cited:
        if extract_numbers(answer_text) and any(
            not _matches(n, allowed_numbers([], question)) for n in extract_numbers(answer_text)
        ):
            problems.append("numbers stated without any cited result")
        return VerifyResult(ok=not problems, problems=problems)
    if any(r.kind != "answer" for r in cited):
        problems.append("cited a result that is not an answer")
    allowed = allowed_numbers(cited, question)
    for n in extract_numbers(answer_text):
        if not _matches(n, allowed):
            problems.append(f"unsupported number: {n.text}")
    # polarity: single-row, single boolean-like cell
    for r in cited:
        if len(r.rows) == 1:
            flags = [str(c).strip().lower() for c in r.rows[0] if isinstance(c, (str, bool))]
            bools = [f for f in flags if f in _TRUE | _FALSE]
            if len(bools) == 1 and len(r.rows[0]) <= 3:
                if bools[0] in _FALSE and not _NEGATION.search(answer_text):
                    problems.append("flag is False/No but the answer does not state a negation")
    return VerifyResult(ok=not problems, problems=problems)


def fallback_text(results: list[QueryResult], max_rows: int = 10) -> str:
    """Deterministic, number-safe answer built straight from the last answer result."""
    answers = [r for r in results if r.kind == "answer"]
    if not answers:
        reasons = [r.message for r in results if r.message]
        return reasons[-1] if reasons else "I couldn't find a reliable answer to this question."
    r = answers[-1]
    ctx = ", ".join(x for x in (r.scope_label, r.period_label) if x)
    head = f"Result{f' ({ctx})' if ctx else ''}:"
    if len(r.rows) == 1:
        parts = [f"{c.replace('_', ' ')}: {v}" for c, v in zip(r.columns, r.rows[0])]
        return f"{head} " + "; ".join(parts) + "."
    lines = [head]
    for row in r.rows[:max_rows]:
        lines.append("- " + ", ".join(f"{c.replace('_', ' ')}: {v}" for c, v in zip(r.columns, row)))
    if len(r.rows) > max_rows:
        lines.append(f"... and {len(r.rows) - max_rows} more rows.")
    return "\n".join(lines)
