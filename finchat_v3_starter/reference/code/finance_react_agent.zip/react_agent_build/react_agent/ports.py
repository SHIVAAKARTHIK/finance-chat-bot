"""Ports: the only contact points between the agent and the existing Finance Chat code.

The host implements these protocols with thin adapters over the existing modules
(semantic_silver picker / cache / compiler / guard / runtime, KPI planner). The agent never
imports those modules directly, so this package stays portable and testable.

Security contract (the host MUST keep it):
- The user identity, roles, entity scopes and PII permission live in `UserContext`, created by
  the host from the authenticated request. The model can never set or change them.
- Every port method enforces scope, approved joins, casts and PII masking itself. The agent
  only asks; it never builds SQL.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, Sequence


@dataclass(frozen=True)
class UserContext:
    """Created by the host from the authenticated request. Opaque to the model."""

    user_id: str
    roles: tuple[str, ...] = ()
    can_view_pii: bool = False
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class TableCandidate:
    table: str  # fully qualified, e.g. lakehouse_mvpai.silver.fact_fynapse_slr_journals
    domain: str  # e.g. adra, subledger
    role: Literal["fact", "dim", "other"]
    summary: str  # one line from INDEX.md
    score: float = 0.0


@dataclass
class ValueMatch:
    kind: str  # entity | period | account | column_value
    value: str  # canonical value to put in a spec (e.g. "100 - 100-Northwind", "Feb 25")
    label: str  # human label
    score: float = 1.0


ResultKind = Literal[
    "answer", "not_found", "clarify", "cannot_compare", "pii_restricted", "access_denied",
    "domain_not_enabled", "timeout", "error",
]


@dataclass
class QueryResult:
    """Outcome of one guarded query (silver spec or KPI)."""

    kind: ResultKind
    columns: list[str] = field(default_factory=list)
    rows: list[list[Any]] = field(default_factory=list)
    message: str = ""  # reason / clarification text, safe to show
    scope_label: str = ""  # e.g. "Entity 100 - 100-Northwind"
    period_label: str = ""  # e.g. "Feb 25"
    tables: list[str] = field(default_factory=list)
    sql_rendered: str = ""  # masked, display-only
    source: Literal["semantic_silver", "kpi"] = "semantic_silver"
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class KpiCandidate:
    kpi_id: str
    name: str
    domain: str
    description: str
    score: float = 0.0


class SilverPort(Protocol):
    def find_tables(self, question: str, user: UserContext, limit: int = 6) -> Sequence[TableCandidate]: ...

    def get_table_page(self, table: str, user: UserContext) -> str:
        """Generated skill page (prompts/silver_tables/<table>.md). Empty string if not allowed."""
        ...

    def lookup_values(
        self, kind: str, text: str, user: UserContext, table: str | None = None, column: str | None = None
    ) -> Sequence[ValueMatch]: ...

    def query(self, spec: dict[str, Any], user: UserContext) -> QueryResult:
        """Validate + resolve + compile + guard + execute a semantic-silver spec (existing pipeline)."""
        ...


class KpiPort(Protocol):
    def find_kpis(self, question: str, user: UserContext, limit: int = 5) -> Sequence[KpiCandidate]: ...

    def run_kpi(self, kpi_id: str, filters: dict[str, Any], user: UserContext) -> QueryResult: ...
