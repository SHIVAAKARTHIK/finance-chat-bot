"""Model client abstraction + Amazon Bedrock Converse implementation.

The loop talks to `ModelClient` only. Tests use a scripted fake; production uses
`BedrockConverseClient` (boto3 is imported lazily so this package imports without it).
Messages use the Bedrock Converse content-block shape:
  {"role": "user"|"assistant", "content": [{"text": ...} | {"toolUse": {...}} | {"toolResult": {...}}]}
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class ToolCall:
    id: str
    name: str
    input: dict[str, Any]


@dataclass
class ModelTurn:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    stop_reason: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    raw_content: list[dict[str, Any]] = field(default_factory=list)  # assistant content blocks


class ModelClient(Protocol):
    def converse(
        self,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        max_tokens: int,
        temperature: float,
        timeout_s: float,
    ) -> ModelTurn: ...


class BedrockConverseClient:
    """Bedrock Converse API with tool use. Credentials come from the host's normal AWS setup."""

    def __init__(self, model_id: str, region_name: str | None = None, client: Any = None):
        if not model_id:
            raise ValueError("model_id is required (set FINANCE_AGENT_MODEL_ID)")
        self.model_id = model_id
        self._client = client
        self._region = region_name

    def _get_client(self, timeout_s: float):
        if self._client is None:
            import boto3  # lazy
            from botocore.config import Config

            cfg = Config(read_timeout=timeout_s, connect_timeout=min(5.0, timeout_s), retries={"max_attempts": 1})
            self._client = boto3.client("bedrock-runtime", region_name=self._region, config=cfg)
        return self._client

    def converse(self, system, messages, tools, max_tokens, temperature, timeout_s) -> ModelTurn:
        client = self._get_client(timeout_s)
        resp = client.converse(
            modelId=self.model_id,
            system=[{"text": system}],
            messages=messages,
            toolConfig={"tools": tools, "toolChoice": {"any": {}}},
            inferenceConfig={"maxTokens": max_tokens, "temperature": temperature},
        )
        content = resp.get("output", {}).get("message", {}).get("content", []) or []
        turn = ModelTurn(
            stop_reason=resp.get("stopReason", ""),
            input_tokens=int(resp.get("usage", {}).get("inputTokens", 0) or 0),
            output_tokens=int(resp.get("usage", {}).get("outputTokens", 0) or 0),
            raw_content=content,
        )
        texts = []
        for block in content:
            if "text" in block:
                texts.append(block["text"])
            elif "toolUse" in block:
                tu = block["toolUse"]
                turn.tool_calls.append(ToolCall(id=tu["toolUseId"], name=tu["name"], input=tu.get("input") or {}))
        turn.text = "\n".join(texts).strip()
        return turn
