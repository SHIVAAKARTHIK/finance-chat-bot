"""When to use the agent instead of the fast single-spec path.

Default policy (hybrid): simple questions stay on the fast path; the agent handles questions that
look multi-step, and questions where the fast path returned a coverage refusal (not a safety
refusal). Safety outcomes (access denied, PII restricted, domain not enabled) are never retried.
"""
from __future__ import annotations

import re

_COMPLEX = re.compile(
    r"\b(why|explain|driv(e|es|en|ing)|compare|versus|vs\.?|trend|change(d)? (from|between)|"
    r"and (how|what|which|who)|both|as well as|breakdown and|then)\b",
    re.IGNORECASE,
)

# Fast-path outcomes the agent may try to recover (coverage gaps).
RETRYABLE = {"clarify", "model_clarification", "not_found", "query_failed", "spec_rejected",
             "pick_failed", "timeout", "error"}
# Outcomes that must stand (safety / correct refusals).
FINAL = {"access_denied", "pii_restricted", "domain_not_enabled", "cannot_compare", "answer"}


def looks_complex(question: str) -> bool:
    return bool(_COMPLEX.search(question or "")) or (question or "").count("?") > 1


def should_use_agent(question: str, fast_path_kind: str | None = None, fast_path_reason: str | None = None,
                     mode: str = "hybrid") -> bool:
    """mode: off | hybrid | always."""
    if mode == "off":
        return False
    if mode == "always":
        return True
    if fast_path_kind is None:  # deciding before the fast path ran
        return looks_complex(question)
    if fast_path_kind in FINAL:
        return False
    return fast_path_kind in RETRYABLE or (fast_path_reason or "") in RETRYABLE
