"""Build a local DuckDB copy of the silver tables (ADRA, Fynapse, FA) whose aggregates match the
verified ground truth (business sheets + the SQL run of 2026-11-15). Names of people are fictional.

Usage:  python fixtures/build_fixture.py [out.duckdb]     (default: in-memory, returns the connection)
"""
from __future__ import annotations

import sys
from decimal import Decimal

D = Decimal
CATALOG, SCHEMA = "lakehouse_mvpai", "silver"


def _fqn(t: str) -> str:
    return f"{CATALOG}.{SCHEMA}.{t}"


def _create(con, table: str, cols: list[tuple[str, str]], rows: list[tuple]) -> None:
    con.execute(f"CREATE OR REPLACE TABLE {_fqn(table)} ({', '.join(f'{c} {t}' for c, t in cols)})")
    if rows:
        con.executemany(f"INSERT INTO {_fqn(table)} VALUES ({', '.join('?' * len(cols))})", rows)


def _split(total: D, n: int, step: D = D("100")) -> list[D]:
    """n positive parts that sum exactly to total (multiples of step except the last)."""
    if n <= 0:
        return []
    base = (total / n // step) * step
    parts = [base] * (n - 1)
    parts.append(total - base * (n - 1))
    return parts


# =============================================================================== ADRA
def build_adra(con) -> None:
    S = "VARCHAR"
    ents = [("581", "14781", "100", "100-Northwind", "Active", "US", "USD"),
            ("581", "14782", "561", "561 - Cars USA Shipping, LLC", "Active", "US", "USD")]
    _create(con, "adra_legal_entity_dimensions",
            [(c, S) for c in ("ENGAGEMENT_KEY", "LEGAL_ENTITY_KEY", "ENTITY_CODE", "ENTITY_NAME", "STATUS", "COUNTRY",
                              "ENTITY_CURRENCY_CODE")], ents)
    periods = [("P2501", "581", "14781", "Jan 25", "2025-01-31 Jan 25", "2025-01-01", "2025-01-31", "Closed"),  # no facts
               ("P2502", "581", "14781", "Feb 25", "2025-02-28 Feb 25", "2025-02-01", "2025-02-28", "Open"),
               ("P2610", "581", "14782", "Oct 26", "2026-10-31 Oct 26", "2026-10-01", "2026-10-31", "Open"),
               ("P2610", "581", "9819", "Oct 26", "2026-10-31 Oct 26", "2026-10-01", "2026-10-31", "Open")]
    _create(con, "adra_period_dimensions",
            [(c, S) for c in ("PERIOD_KEY", "ENGAGEMENT_KEY", "LEGAL_ENTITY_KEY", "PERIOD_NAME", "PERIOD",
                              "PERIOD_START", "PERIOD_END", "PERIOD_STATUS")], periods)

    acct_dim, facts, txns = [], [], []

    def add_account(le, key, number, name, status, finalized, balance, unid, rtype="Bank",
                    preparer="Preparer A", approver="", approved_date="", period="P2502"):
        acct_dim.append((key, "581", le, key, number, name, "Balance Sheet", "Asset", "Not set", rtype, "False"))
        facts.append((key, "581", le, period, preparer, approver, "", "", status, "True" if finalized else "False",
                      "False", f"{balance:.2f}", f"{abs(balance):.2f}", f"{unid:.2f}", f"{abs(unid):.2f}",
                      "0", "0", "2026-10-20 10:00:00" if status != "Not prepared" else "", approved_date))

    # ---- 100-Northwind, Feb 25: 40 accounts. Approved 7 (2 finalized), Prepared 9, Not prepared 24.
    le = "14781"
    named = [("103300", "WF - Corp Sweep", "Approved", False, D("12500.00"), D("0.00")),
             ("103703", "Mutual Funds (Long Term)", "Approved", True, D("45000.00"), D("1200.00")),
             ("141111", "Premium Receivable - Current - Direct", "Not prepared", False, D("1981646.00"), D("992715.00")),
             ("222120", "Municipal taxes payable", "Prepared", False, D("-8400.00"), D("3100.00"))]
    statuses = (["Approved"] * 5 + ["Prepared"] * 8 + ["Not prepared"] * 23)  # remaining 36
    finalized_left = 1  # one more approved+finalized (total 2)
    rest_balance = D("2143711.00") - sum(n[4] for n in named)
    rest_unid = D("3940448.00") - sum(n[5] for n in named)
    bal_parts = _split(rest_balance, 36, D("1"))
    unid_parts = _split(rest_unid, 36, D("1"))
    for i, (num, name, st, fin, bal, unid) in enumerate(named):
        add_account(le, f"A{num}", num, name, st, fin, bal, unid,
                    approver="Approver B" if st == "Approved" else "",
                    approved_date="2026-10-25 04:59:14" if num == "103703" else "")
    for i, st in enumerate(statuses):
        fin = False
        if st == "Approved" and finalized_left:
            fin, finalized_left = True, 0
        add_account(le, f"N{i:03d}", f"9{i:05d}", f"Account {i}", st, fin, bal_parts[i], unid_parts[i],
                    approver="Approver B" if st == "Approved" else "")

    # ---- 561 - Cars USA Shipping, Oct 26: 23 accounts. Approved 6 (all finalized), Prepared 6, Not prepared 11.
    le = "14782"
    top = [("213230", "COST OF SALES ACCRUAL", D("19697737.46")), ("122400", "ACCOUNTS RECEIVABLE THIRD PARTY", D("6294506.33")),
           ("161100", "Net Sweeps", D("2520421.50")), ("213440", "Accounts Payable", D("1193073.56")),
           ("162600", "DUE TO/FROM", D("815070.06"))]
    others = [("213130", "ACCOUNTS RECEIVABLE CREDIT BALANCES"), ("153300", "Prepaid expenses")] + \
             [(f"8{i:05d}", f"Account {i}") for i in range(16)]
    st561 = ["Approved"] * 6 + ["Prepared"] * 6 + ["Not prepared"] * 11
    # unidentified: 213130 = -455,376.16 ; total absolute 22,831,252.26
    unid_other = _split(D("22831252.26") - D("455376.16"), 22, D("1"))
    rows561 = [(n, nm, b) for n, nm, b in top] + [(n, nm, D("1000.00") + i) for i, (n, nm) in enumerate(others)]
    order = {"213130": "Not prepared"}
    st_iter = iter([s for s in st561 if s != "Not prepared"] + ["Not prepared"] * 10)
    k = 0
    for num, nm, bal in rows561:
        st = order.get(num) or next(st_iter)
        if num == "213130":
            unid = D("-455376.16")
        else:
            unid = unid_other[k]
            k += 1
        add_account(le, f"C{num}", num, nm, st, st == "Approved", bal, unid, period="P2610",
                    approver="Approver C" if num == "213130" or st == "Approved" else "")
    # orphan fact row (entity key missing from the entity dimension), seen in the real data
    facts.append(("X1", "581", "9819", "P2610", "", "", "", "", "Prepared", "False", "False", "10.00", "10.00",
                  "0.00", "0.00", "0", "0", "", ""))

    _create(con, "adra_account_dimensions",
            [(c, S) for c in ("ACCOUNT_KEY", "ENGAGEMENT_KEY", "LEGAL_ENTITY_KEY", "ACCOUNT_ID", "ACCOUNT_NUMBER",
                              "ACCOUNT_NAME", "ACCOUNT_CLASS", "ACCOUNT_TYPE", "RISK_TYPE", "RECONCILIATION_TYPE",
                              "IS_KEY_ACCOUNT")], acct_dim)
    _create(con, "adra_account_facts",
            [(c, S) for c in ("ACCOUNT_KEY", "ENGAGEMENT_KEY", "LEGAL_ENTITY_KEY", "PERIOD_KEY", "PREPARER_NAME",
                              "APPROVER_NAME", "REVIEWER_NAME", "ASSIGNED_TO_NAME", "ACCOUNT_STATUS", "IS_FINALIZED",
                              "IS_CARRIED_FORWARD", "BALANCE", "BALANCE_ABS", "UNIDENTIFIED_BALANCE",
                              "UNIDENTIFIED_BALANCE_ABS", "NO_OF_DOCUMENTS", "NO_OF_REJECTS", "PREPARED_DATE",
                              "APPROVED_DATE")], facts)

    # ---- transactions
    def txn(i, le, key, period, ttype, status, amount, age, group="0-30 Days"):
        txns.append((f"H{i:04d}", f"T{i:04d}", key, "581", le, period, ttype, status, f"{amount:.2f}",
                     f"{abs(amount):.2f}", str(age), group, "44", "Clerk D", "item"))

    i = 0
    for amount, age in ((D("6000.00"), 18), (D("-3438.00"), 12)):  # Northwind 222120: 2 txns, 9,438.00 abs, max age 18
        i += 1
        txn(i, "14781", "A222120", "P2502", "Ledger transaction", "Required adjustment", amount, age)
    # 561: 16 txns: 8 ledger / 8 subledger; 11 Required adjustment / 5 Not Set; 153300 has 2 (abs 913.30)
    for amount in (D("500.00"), D("-413.30")):
        i += 1
        txn(i, "14782", "C153300", "P2610", "Ledger transaction", "Required adjustment", amount, 7)
    for j in range(14):
        i += 1
        ttype = "Ledger transaction" if j < 6 else "Subledger transaction"
        status = "Required adjustment" if j < 9 else "Not Set"
        txn(i, "14782", "C80000" + str(j % 9), "P2610", ttype, status, D("100.00") + j, 3 + j)
    _create(con, "adra_transaction_facts",
            [(c, S) for c in ("HASH_KEY", "TRANSACTION_KEY", "ACCOUNT_KEY", "ENGAGEMENT_KEY", "LEGAL_ENTITY_KEY",
                              "PERIOD_KEY", "TRANSACTION_TYPE", "TRANSACTION_STATUS", "AMOUNT", "AMOUNT_ABS",
                              "AGE_DAYS", "AGE_GROUP", "CURRENCY", "ITEM_ADDED_BY_NAME", "TEXT")], txns)


# =============================================================================== FYNAPSE
def build_fynapse(con) -> None:
    _create(con, "dim_legal_entities", [("legal_entity_id", "VARCHAR"), ("name", "VARCHAR")],
            [(c, f"{c} Insurance Services Ltd") for c in ("UK03", "UK06", "UK07", "UK13", "UK14", "UK17")])
    # (entity, child, period, source, count): matches entity/child pairs, periods, sources from the SQL run
    groups = [("UK03", "BMO", 9, "NOVIDEA", 237), ("UK03", None, 9, "NOVIDEA", 46),
              ("UK07", None, 9, "NOVIDEA", 140), ("UK07", None, 9, "ACCRUAL", 78), ("UK07", "BWM", 9, "ACCRUAL", 62),
              ("UK17", "BWE", 8, "NOVIDEA", 10), ("UK17", "BWE", 8, "ACCRUAL", 74), ("UK17", "BWE", 8, "Concur", 50),
              ("UK17", None, 8, "Concur", 24),
              ("UK14", None, 8, "Concur", 49), ("UK14", None, 9, "Concur", 3),
              ("UK06", None, 9, "Concur", 28), ("UK13", None, 9, "Concur", 16)]
    event = {"NOVIDEA": "BROKERAGE ACCOUNTING", "ACCRUAL": "ACCRUED_BROKERAGE_ACCOUNTING", "Concur": "CONCUR_EXPENSES"}
    rows: list[dict] = []
    for ent, child, per, src, n in groups:
        for _ in range(n):
            rows.append(dict(ent=ent, child=child, per=per, src=src))
    assert len(rows) == 817

    # REPORTING_AMOUNT: pairs net to zero inside (entity, period, source); UK03 gets the top-5 accounts.
    targets = [("199001", D("70996898.63")), ("239001", D("33241275.30")), ("109035", D("24372624.04")),
               ("105203", D("11538461.54")), ("430000", D("4409112.86"))]
    uk03 = [r for r in rows if r["ent"] == "UK03"]
    idx = 0
    for acct, amt in targets:
        uk03[idx].update(acct=acct, rep=amt)
        idx += 1
    remaining = sum(a for _, a in targets)
    c = 0
    while remaining > 0:  # counter lines on distinct accounts, each below the 5th-largest gross
        chunk = min(D("3900000.00"), remaining)
        uk03[idx].update(acct=f"8{c:05d}", rep=-chunk)
        remaining -= chunk
        idx += 1
        c += 1
    small = uk03[idx:]
    for j in range(0, len(small) - 1, 2):
        a = D(100 + j)
        small[j].update(acct=f"7{j:05d}", rep=a)
        small[j + 1].update(acct=f"7{j + 1:05d}", rep=-a)
    if len(small) % 2:
        small[-1].update(acct="700999", rep=D("0.00"))
    others = [r for r in rows if r["ent"] != "UK03"]
    from itertools import groupby
    keyf = lambda r: (r["ent"], r["per"], r["src"])
    for _, grp in groupby(sorted(others, key=keyf), key=keyf):
        g = list(grp)
        for j in range(0, len(g) - 1, 2):
            a = D(250 + j)
            g[j].update(acct=f"6{j:05d}", rep=a)
            g[j + 1].update(acct=f"6{j + 1:05d}", rep=-a)
        if len(g) % 2:
            g[-1].update(acct="600999", rep=D("0.00"))
    # imbalances: UK03 P9 NOVIDEA -0.03, UK07 P9 NOVIDEA -0.03, UK17 P8 NOVIDEA -0.02 (total -0.08)
    for ent, per, delta in (("UK03", 9, D("-0.03")), ("UK07", 9, D("-0.03")), ("UK17", 8, D("-0.02"))):
        r = next(r for r in rows if r["ent"] == ent and r["per"] == per and r["src"] == "NOVIDEA"
                 and r["acct"].startswith(("7", "6")))
        r["rep"] += delta

    # transaction currency counts; each currency nets to zero
    cur_counts = [("USD", 360), ("GBP", 238), ("EUR", 120), ("CAD", 60), ("SEK", 17), ("AUD", 14), ("NOK", 4), ("ZAR", 4)]
    curs = [c for c, n in cur_counts for _ in range(n)]
    for r, cur in zip(rows, curs):
        r["cur"] = cur
    for cur, _ in cur_counts:
        g = [r for r in rows if r["cur"] == cur]
        for j in range(0, len(g) - 1, 2):
            g[j]["tx"], g[j + 1]["tx"] = D(10 + j), -D(10 + j)
        if len(g) % 2:
            g[-1]["tx"] = D("0.00")
    for k, r in enumerate(rows):  # functional currency EUR/GBP, each nets to zero
        r["fcur"] = "GBP" if k % 3 else "EUR"
    for fc in ("EUR", "GBP"):
        g = [r for r in rows if r["fcur"] == fc]
        for j in range(0, len(g) - 1, 2):
            g[j]["fa"], g[j + 1]["fa"] = D(20 + j), -D(20 + j)
        if len(g) % 2:
            g[-1]["fa"] = D("0.00")

    # journals: P9 610 lines in 205 journals (200x3 + 5x2), P8 207 lines in 14 journals (13x15 + 12)
    p9 = [r for r in rows if r["per"] == 9]
    p8 = [r for r in rows if r["per"] == 8]
    assert len(p9) == 610 and len(p8) == 207

    def assign(lines, sizes, prefix):
        pos = 0
        for jn, size in enumerate(sizes):
            for ln in range(size):
                lines[pos].update(jid=f"{prefix}{jn:04d}", lno=ln + 1)
                pos += 1
        assert pos == len(lines)

    assign(p9, [3] * 200 + [2] * 5, "J9")
    assign(p8, [15] * 13 + [12], "J8")
    out = []
    for n, r in enumerate(rows):
        day = 31 if r["per"] == 8 else (n % 30) + 1
        core = f"2026-08-{day:02d}" if r["per"] == 8 else f"2026-09-{day:02d}"
        out.append((r["jid"], f"JL{n:06d}", r["lno"], core, "ACCR" if r["per"] == 8 else "PERM", r["acct"],
                    float(r["tx"]), r["cur"], float(r["fa"]), r["fcur"], float(r["rep"]), "USD", 2026, r["per"],
                    r["ent"], r["child"], r["src"], event[r["src"]], None, None, "CC1"))
    cols = [("JOURNAL_ID", "VARCHAR"), ("JOURNAL_LINE_ID", "VARCHAR"), ("JOURNAL_LINE_NO", "INTEGER"),
            ("CORE_DATE", "DATE"), ("JOURNAL_TYPE", "VARCHAR"), ("ACCOUNT", "VARCHAR"),
            ("TRANSACTION_AMOUNT", "DECIMAL(18,2)"), ("TRANSACTION_CURRENCY", "VARCHAR"),
            ("FUNCTIONAL_AMOUNT", "DECIMAL(18,2)"), ("FUNCTIONAL_CURRENCY", "VARCHAR"),
            ("REPORTING_AMOUNT", "DECIMAL(18,2)"), ("REPORTING_CURRENCY", "VARCHAR"), ("FISCAL_YEAR", "INTEGER"),
            ("PERIOD", "INTEGER"), ("PARENT_ENTITY", "VARCHAR"), ("CHILD_ENTITY", "VARCHAR"),
            ("SOURCE_SYSTEM", "VARCHAR"), ("BUSINESS_EVENT", "VARCHAR"), ("LOB", "VARCHAR"), ("REVERSES", "VARCHAR"),
            ("COST_CENTER", "VARCHAR")]
    _create(con, "fact_fynapse_slr_journals", cols, out)


# =============================================================================== FIXED ASSETS
def build_fa(con) -> None:
    S = "VARCHAR"
    _create(con, "dim_companies", [("DATA_AREA", S), ("NAME", S)], [("dat", "Contoso Demo Company")])
    assets: list[dict] = []
    n = 0

    def add(group, status, price):
        nonlocal n
        n += 1
        assets.append(dict(num=f"{group[:4]}-{n:06d}", group=group, status=status, price=price))

    special = {"AUTO": [("Sold", D("30000")), ("Sold", D("24600"))],
               "COMPUTERS": [("Scrapped", D("20000")), ("Scrapped", D("19700")), ("Scrapped", D("20000"))],
               "FURNITURE": [("Closed", D("16400"))]}
    group_total = {"AUTO": D("892800"), "BUILDINGS": D("651700"), "FURNITURE": D("411600"),
                   "COMPUTERS": D("171500"), "SOFTWARE": D("39000"), "LHI": D("0")}
    acquired_n = {"AUTO": 40, "BUILDINGS": 20, "FURNITURE": 60, "COMPUTERS": 59, "SOFTWARE": 20, "LHI": 0}
    for g, total in group_total.items():
        sp = special.get(g, [])
        for st, p in sp:
            add(g, st, p)
        rest_n = acquired_n[g] - len(sp)
        for p in _split(total - sum(p for _, p in sp), rest_n):
            add(g, "Open", p)
    not_activated = {"AUTO": 10, "BUILDINGS": 5, "FURNITURE": 30, "COMPUTERS": 30, "SOFTWARE": 16, "LHI": 10}
    for g, k in not_activated.items():
        for _ in range(k):
            add(g, "NoAcquisition", D("0"))
    assert len(assets) == 300, len(assets)
    books, master = [], []
    for load, mdp in ((1, "2026-10-01 00:00:00"), (2, "2026-11-10 00:00:00")):  # duplicate load (known issue)
        for a in assets:
            books.append(("dat", a["num"], "GAAP", a["status"], f"{a['price']:.2f}", a["group"], "2024-01-15",
                          f"BK{load}-{a['num']}", mdp))
    for a in assets:
        master.append(("dat", a["num"], f"{a['group'].title()} asset {a['num']}", a["group"], "Tangible", "Contact X", "Owner Y"))
    _create(con, "dim_fixed_asset_books",
            [("DATA_AREA_ID", S), ("FIXED_ASSET_NUMBER", S), ("BOOK_ID", S), ("STATUS", S), ("ACQUISITION_PRICE", S),
             ("FIXED_ASSET_GROUP_ID", S), ("ACQUISITION_DATE", S), ("HASH_KEY", S), ("MDP_MODIFIED_DATE", "TIMESTAMP")], books)
    _create(con, "dim_fixed_assets",
            [("DATA_AREA_ID", S), ("FIXED_ASSET_NUMBER", S), ("ASSET_NAME", S), ("FIXED_ASSET_GROUP_ID", S),
             ("ASSET_TYPE", S), ("CONTACT_NAME", S), ("RESPONSIBLE_NAME", S)], master)
    types = ([("Depreciation", 1500), ("Depreciation (this year)", 272), ("Acquisition", 200),
              ("Acquisition adjustment", 8), ("Disposal - sale", 5), ("Disposal - scrap", 4), ("Revaluation", 14)])
    tx = []
    i = 0
    for t, cnt in types:
        for k in range(cnt):
            i += 1
            a = assets[i % len(assets)]
            tx.append(dict(asset=a["num"], type=t, amount=D(-(10 + k % 50)) if "Depreciation" in t else D(100 + k),
                           date=f"2026-{(k % 10) + 1:02d}-15", i=i))
    assert len(tx) == 2003
    rows = []
    for load in (1, 2):
        for r in tx:
            rows.append(("dat", r["asset"], r["type"], f"{r['amount']:.2f}", r["date"], "GAAP", f"TX{load}-{r['i']:05d}",
                         "2026-10-01 00:00:00" if load == 1 else "2026-11-10 00:00:00"))
    _create(con, "fact_asset_master_transactions",
            [("ENTITY_ID", S), ("ASSET_ID", S), ("TRANSACTION_TYPE", S), ("AMOUNT", S), ("POSTING_DATE", S),
             ("BOOK_TYPE", S), ("HASH_KEY", S), ("MDP_MODIFIED_DATE", "TIMESTAMP")], rows)


def build(path: str = ":memory:"):
    import duckdb

    con = duckdb.connect(path)
    con.execute(f"ATTACH ':memory:' AS {CATALOG}")
    con.execute(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
    build_adra(con)
    build_fynapse(con)
    build_fa(con)
    return con


if __name__ == "__main__":
    c = build(sys.argv[1] if len(sys.argv) > 1 else ":memory:")
    for t in ("adra_account_facts", "adra_transaction_facts", "fact_fynapse_slr_journals", "dim_fixed_asset_books",
              "fact_asset_master_transactions"):
        print(t, c.execute(f"SELECT COUNT(*) FROM {_fqn(t)}").fetchone()[0])
