"""Run the real ground-truth SQL (fixtures/ground_truth_adra_fynapse_v1.sql) on the local fixture and
compare with the values returned by Databricks on 2026-11-15. Exit code 1 on any mismatch."""
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from build_fixture import build  # noqa: E402

EXPECTED = {
    ("A01", "balance"): "1981646.00", ("A02", "status=Not prepared"): "1", ("A03", "is_finalized=False"): "1",
    ("A04", "Approved"): "7", ("A04", "Not prepared"): "24", ("A04", "Prepared"): "9",
    ("A05", "Approved"): "6", ("A05", "Not prepared"): "11", ("A05", "Prepared"): "6",
    ("A06", "finalized"): "6", ("A07", "pct_finalized"): "26.1", ("A07", "total_accounts"): "23",
    ("A08", "total_balance"): "2143711.00", ("A09", "total_unidentified_abs"): "3940448.00",
    ("A10", "213230 | COST OF SALES ACCRUAL"): "19697737.46", ("A10", "122400 | ACCOUNTS RECEIVABLE THIRD PARTY"): "6294506.33",
    ("A10", "161100 | Net Sweeps"): "2520421.50", ("A10", "213440 | Accounts Payable"): "1193073.56",
    ("A10", "162600 | DUE TO/FROM"): "815070.06", ("A11", "Not set"): "40", ("A12", "Bank"): "22831252.26",
    ("A13", "accounts_without_documents"): "40", ("A14", "total_rejections"): "0", ("A15", "transactions"): "2",
    ("A16", "total_amount_abs"): "913.30", ("A17", "Ledger transaction"): "8", ("A17", "Subledger transaction"): "8",
    ("A18", "max_age_days"): "18", ("A19", "0-30 Days"): "16", ("A22", "preparer_populated"): "yes",
    ("A23", "approver_populated"): "yes", ("A25", "approved_not_finalized"): "5",
    ("F01", "UK03 lines"): "283", ("F01", "UK03 net"): "-0.03", ("F01", "UK06 lines"): "28", ("F01", "UK06 net"): "0.00",
    ("F01", "UK07 lines"): "280", ("F01", "UK07 net"): "-0.03", ("F01", "UK13 lines"): "16", ("F01", "UK13 net"): "0.00",
    ("F01", "UK14 lines"): "52", ("F01", "UK14 net"): "0.00", ("F01", "UK17 lines"): "158", ("F01", "UK17 net"): "-0.02",
    ("F02", "FY2026 P8 net"): "-0.02", ("F02", "FY2026 P9 net"): "-0.06", ("F03", "PERM"): "610",
    ("F04", "199001"): "70996898.63", ("F04", "239001"): "33241275.30", ("F04", "109035"): "24372624.04",
    ("F04", "105203"): "11538461.54", ("F04", "430000"): "4409112.86",
    ("F05", "USD lines"): "360", ("F05", "GBP lines"): "238", ("F05", "EUR lines"): "120", ("F05", "CAD lines"): "60",
    ("F05", "SEK lines"): "17", ("F05", "AUD lines"): "14", ("F05", "NOK lines"): "4", ("F05", "ZAR lines"): "4",
    ("F05", "USD amount"): "0.00", ("F05", "GBP amount"): "0.00", ("F05", "SEK amount"): "0.00",
    ("F06", "UK07 lines"): "280", ("F07", "UK17 P8 net"): "-0.02", ("F08", "distinct_journals_P9"): "205",
    ("F09", "reversal_lines"): "0", ("F10", "BROKERAGE ACCOUNTING"): "433", ("F10", "ACCRUED_BROKERAGE_ACCOUNTING"): "214",
    ("F10", "CONCUR_EXPENSES"): "170", ("F11", "UK03"): "34.6", ("F11", "UK06"): "3.4", ("F11", "UK07"): "34.3",
    ("F11", "UK13"): "2.0", ("F11", "UK14"): "6.4", ("F11", "UK17"): "19.3", ("F12", "no_child_entity"): "384",
    ("F13", "(null)"): "817", ("F16", "EUR"): "0.00", ("F16", "GBP"): "0.00",
}


def _same(got, want: str) -> bool:
    if got is None:
        return False
    try:
        return abs(Decimal(str(got)) - Decimal(want)) < Decimal("0.005")
    except Exception:
        return str(got) == want


def main() -> int:
    con = build()
    sql = (Path(__file__).parent / "ground_truth_adra_fynapse_v1.sql").read_text()
    got = {(q, k): v for q, k, v in con.execute(sql).fetchall()}
    bad = [(k, v, got.get(k)) for k, v in EXPECTED.items() if not _same(got.get(k), v)]
    print(f"checked {len(EXPECTED)} ground-truth values, mismatches: {len(bad)}")
    for b in bad:
        print("  MISMATCH", b)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
