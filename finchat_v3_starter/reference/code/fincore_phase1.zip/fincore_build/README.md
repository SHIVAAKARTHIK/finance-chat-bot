# fincore - Finance Chat core (phase 1)

A clean, config-driven core for Finance Chat: semantic layer, query engine, access control,
KPI registry and executors. Everything except the FastAPI app. The LLM never writes SQL: it
produces a `QuerySpec`; this package resolves, compiles, checks and executes it.

```
question --(LLM / KPI match / agent)--> QuerySpec --> SemanticEngine --> QueryResult
                                                       |-- validate spec against the catalog
                                                       |-- access: domain, tables, entity scopes, PII
                                                       |-- resolve entity (names, codes, no LLC/punct.)
                                                       |-- resolve period (Feb 25 / February 2025 / 2025-02 / FY2026 P9 / latest / compare)
                                                       |-- resolve identifiers (account, asset, journal) via approved joins
                                                       |-- data quality: grain uniqueness, join fan-out
                                                       |-- compile (sqlglot -> databricks or duckdb), guard, execute
                                                       '-- not found / share / notes
```

## Layout

| Path | What |
|---|---|
| `fincore/semantic/` | Metadata models + YAML catalog loader |
| `fincore/access/` | `UserContext`, `YamlAccessProvider` (swap for an entitlement table / Entra groups) |
| `fincore/query/spec.py` | `QuerySpec` (what the LLM or a KPI asks for) |
| `fincore/query/engine.py` | `SemanticEngine.run(spec, user) -> QueryResult` |
| `fincore/query/compiler.py`, `sqlbuild.py` | Deterministic SQL builder (casts, scope, period, joins, PII mask, share) |
| `fincore/query/lookup.py` | Scoped lookups: entity labels, periods with data, identifier location, grain checks (cached) |
| `fincore/query/guard.py` | Read-only / single SELECT / allowed tables / LIMIT |
| `fincore/kpi/registry.py` | Governed KPIs as YAML spec templates + safe derived values |
| `fincore/exec/` | `DuckDBExecutor` (tests), `DatabricksExecutor` (production, warm connection) |
| `config/semantic/` | `domains.yaml`, `tables/*.yaml`, `joins.yaml` |
| `config/rules/*.md` | Business rules per domain (for the LLM prompt) |
| `config/kpis/*.yaml` | KPI definitions |
| `fixtures/` | Local DuckDB copy of ADRA / Fynapse / FA that reproduces the verified ground truth |
| `tests/` | 78 tests: ground truth, security, data quality, KPIs |

## Run locally

```
pip install pydantic sqlglot pyyaml duckdb pytest
python fixtures/verify_fixture.py        # fixture vs. your Databricks ground-truth SQL: 80/80
python -m pytest -q -W error tests       # 78 passed
```

## Connect to Databricks (on your laptop)

```python
from databricks import sql
from fincore.semantic.catalog import Catalog
from fincore.access.models import YamlAccessProvider
from fincore.exec.databricks_exec import DatabricksExecutor
from fincore.query.engine import SemanticEngine

executor = DatabricksExecutor(lambda: sql.connect(server_hostname=..., http_path=..., credentials_provider=...))
executor.warm_up()                                   # at app start
engine = SemanticEngine(Catalog.load("config"), executor)
user = YamlAccessProvider("config/access.yaml").user_context(user_id, groups)
result = engine.run(spec_dict, user)                  # QueryResult
```
Use your existing connection settings (`.env`); this package never reads secrets.

## Key design rules

- No table- or question-specific code. Domains, tables, joins, scopes, periods, identifiers, PII,
  synonyms and business rules are YAML.
- Fail closed: no scope -> access_denied; unknown entity/period/account -> not_found with the reason;
  duplicate rows at the grain or a fan-out join -> data_quality (answer withheld).
- Only approved many-to-one joins from the anchor, checked at runtime for uniqueness on the join key.
- Balances (`additive: false`) are never summed across periods.
- Person columns (`pii: true`) are masked unless the user may view PII; filtering/grouping by them is refused.
- Values are literals escaped by sqlglot; the guard re-parses the SQL before execution.

## Known limits (phase 1)

- Joins are single-hop (fact -> dimension). Cross-fact questions need two queries (phase 2 agent does this).
- `fact_asset_master_transactions` grain is `HASH_KEY`, which cannot detect the duplicate loads; configure a
  business key or `current_row_rule` once the data team confirms which load is current.
- Fixture amounts outside the verified aggregates are synthetic.

## Phase 2 (next)

1. LLM spec generation (Bedrock Converse, structured tool output) using generated table pages + domain rules,
   with automatic repair from `QueryResult.errors`.
2. Router: KPI match -> governed KPI; else fast spec path; complex/failed -> guarded ReAct agent
   (the agent package, wired directly to this engine).
3. Answer layer: verified narration, tables, "how this was calculated".
4. Catalog generator from profiles + review CSV workflow (replaces hand-written table YAML).
5. Eval runner: question bank through the full NL path, scorecard, regression gate.
