"""Security, data-quality, period-semantics and KPI tests."""
from __future__ import annotations

from pathlib import Path

import pytest

from fincore.kpi.registry import KpiRegistry, safe_eval
from fincore.query.guard import check_sql
from fincore.semantic.catalog import Catalog
from fincore.semantic.models import CurrentRowRule

ROOT = Path(__file__).resolve().parents[1]


def one(r):
    assert r.kind == "answer", (r.kind, r.code, r.message, r.errors)
    return r.rows[0][0]


# ------------------------------------------------------------------ access and scope
def test_entity_outside_scope_is_not_found_and_not_leaked(engine, access):
    nw = access.user_context("TEST_northwind")
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}],
                    "entity_mention": "561", "period_mention": "Oct 26"}, nw)
    assert r.kind == "not_found" and r.code == "entity_not_found"
    assert all("561" not in o for o in r.options)  # options list only the user's own entities


def test_domain_not_granted(engine, access):
    nw = access.user_context("TEST_northwind")
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}]}, nw)
    assert r.kind == "access_denied"


def test_partial_entity_scope_only_counts_granted_entities(engine, piiv):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}]}, piiv)
    assert one(r) == 283 + 280  # pii_viewer only has UK03 and UK07


def test_entity_required_when_several_adra_entities(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}], "period_mention": "latest"}, std)
    assert r.kind == "clarify" and r.code == "entity_required" and len(r.options) == 2


def test_orphan_entity_row_never_counted(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}], "entity_mention": "561",
                    "period_mention": "Oct 26"}, std)
    assert one(r) == 23  # the 9819 row is outside every scope


# ------------------------------------------------------------------ PII
def test_pii_filter_and_group_refused(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}], "entity_mention": "Northwind",
                    "period_mention": "Feb 25", "filters": [{"column": "PREPARER_NAME", "value": "Preparer A"}]}, std)
    assert r.kind == "pii_restricted"
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}], "entity_mention": "Northwind",
                    "period_mention": "Feb 25", "dimensions": [{"column": "PREPARER_NAME"}]}, std)
    assert r.kind == "pii_restricted"


def test_pii_viewer_may_group_by_person(engine, piiv):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows", "alias": "n"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25", "dimensions": [{"column": "PREPARER_NAME"}]}, piiv)
    assert r.kind == "answer" and dict((a, b) for a, b in r.rows) == {"Preparer A": 40}


# ------------------------------------------------------------------ injection and guard
def test_filter_value_injection_is_a_literal(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}], "entity_mention": "Northwind",
                    "period_mention": "Feb 25",
                    "filters": [{"column": "ACCOUNT_STATUS", "value": "x' OR 1=1; DROP TABLE t; --"}]}, std)
    assert r.kind == "answer" and r.rows[0][0] == 0
    assert "DROP" not in r.sql_rendered.split("'")[0]


def test_spec_cannot_carry_sql_or_scope(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}], "sql": "SELECT 1"}, std)
    assert r.kind == "invalid_spec"
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}],
                    "scopes": [{"LEGAL_ENTITY_KEY": "9819"}]}, std)
    assert r.kind == "invalid_spec"


@pytest.mark.parametrize("sql,problem", [
    ("DROP TABLE lakehouse_mvpai.silver.adra_account_facts", "only SELECT"),
    ("SELECT * FROM lakehouse_mvpai.silver.secret_table LIMIT 1", "table not allowed"),
    ("SELECT * FROM lakehouse_mvpai.silver.adra_account_facts", "missing LIMIT"),
    ("SELECT 1 LIMIT 1; SELECT 2 LIMIT 1", "exactly one statement"),
])
def test_guard(sql, problem):
    probs = check_sql(sql, "duckdb", {"lakehouse_mvpai.silver.adra_account_facts"})
    assert any(problem in p for p in probs), probs


def test_unapproved_or_cross_domain_join_refused(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}],
                    "dimensions": [{"column": "ACCOUNT_STATUS"}]}, std)
    assert r.kind == "invalid_spec" and r.code == "unknown_column"
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}],
                    "dimensions": [{"column": "ACCOUNT_NAME", "table": "adra_account_dimensions"}]}, std)
    assert r.kind == "invalid_spec" and r.code == "join_unapproved"


def test_invalid_spec_returns_fixable_errors(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "sum", "column": "ACCOUNT_STATUS"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert r.kind == "invalid_spec" and "numeric" in r.message
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "median", "column": "BALANCE"}]}, std)
    assert r.kind == "invalid_spec" and r.errors


# ------------------------------------------------------------------ period semantics
def test_balances_never_summed_across_periods(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "sum", "column": "BALANCE"}],
                    "entity_mention": "Northwind", "period_policy": "all"}, std)
    assert r.kind == "answer" and r.period_label == "Feb 25" and any("point-in-time" in n for n in r.notes)


def test_counts_can_use_all_periods(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}], "period_policy": "all"}, std)
    assert one(r) == 817 and r.period_label == "All periods"


# ------------------------------------------------------------------ data quality (FA duplicate loads)
def test_fa_duplicate_load_is_withheld(engine, std):
    r = engine.run({"anchor": "dim_fixed_asset_books", "measures": [{"op": "count_rows"}]}, std)
    assert r.kind == "data_quality" and r.code == "grain_not_unique" and "300 duplicate" in r.message


@pytest.fixture()
def fa_engine(con):
    """Catalog with the current-row rule enabled (what we'd do once the data team confirms it)."""
    from fincore.exec.duckdb_exec import DuckDBExecutor
    from fincore.query.engine import SemanticEngine

    cat = Catalog.load(ROOT / "config")
    books = cat.tables["dim_fixed_asset_books"]
    books.current_row_rule = CurrentRowRule(partition_by=["DATA_AREA_ID", "FIXED_ASSET_NUMBER", "BOOK_ID"],
                                            order_by="MDP_MODIFIED_DATE")
    return SemanticEngine(cat, DuckDBExecutor(con=con))


def test_fa_answers_with_current_row_rule(fa_engine, std):
    r = fa_engine.run({"anchor": "dim_fixed_asset_books", "measures": [{"op": "count_rows", "alias": "assets"}],
                       "dimensions": [{"column": "STATUS"}], "share_of_total": True}, std)
    by = {row[0]: row[1] for row in r.rows}
    share = {row[0]: round(row[2], 1) for row in r.rows}
    assert sum(by.values()) == 300 and by["NoAcquisition"] == 101 and share["NoAcquisition"] == 33.7
    r = fa_engine.run({"anchor": "dim_fixed_asset_books",
                       "measures": [{"op": "sum", "column": "ACQUISITION_PRICE", "alias": "v"}],
                       "dimensions": [{"column": "FIXED_ASSET_GROUP_ID"}], "share_of_total": True,
                       "order_by": "v"}, std)
    v = {row[0]: row[1] for row in r.rows}
    assert v["AUTO"] == 892800 and v["BUILDINGS"] == 651700 and v["LHI"] == 0 and sum(v.values()) == 2166600
    assert round(sum(row[2] for row in r.rows if row[0] in ("AUTO", "BUILDINGS")), 1) == 71.3
    r = fa_engine.run({"anchor": "dim_fixed_asset_books", "measures": [{"op": "sum", "column": "ACQUISITION_PRICE", "alias": "v"}],
                       "dimensions": [{"column": "STATUS"}],
                       "filters": [{"column": "STATUS", "op": "in", "value": ["Sold", "Scrapped", "Closed"]}]}, std)
    assert {row[0]: row[1] for row in r.rows} == {"Closed": 16400, "Scrapped": 59700, "Sold": 54600}


# ------------------------------------------------------------------ KPIs
@pytest.fixture()
def kpis(engine):
    return KpiRegistry.load(ROOT / "config" / "kpis", engine)


def test_kpi_completion(kpis, std):
    r = kpis.run("adra_reconciliation_completion", std, entity_mention="Northwind", period_mention="Feb 25")
    vals = dict(zip(r.columns, r.rows[0]))
    assert (vals["finalized"], vals["not_finalized"], vals["total_accounts"], vals["pct_finalized"]) == (2, 38, 40, 5.0)
    assert r.source == "kpi" and r.meta["kpi_status"] == "validated"


def test_kpi_fynapse_lines_by_source(kpis, std):
    r = kpis.run("fynapse_lines_by_source", std)
    assert [row[:2] for row in r.rows] == [["NOVIDEA", 433], ["ACCRUAL", 214], ["Concur", 170]]


def test_kpi_find_and_dimension_whitelist(kpis, std):
    hits = kpis.find("How concentrated is the journal integration workload across source systems?", std)
    assert hits and hits[0].kpi.id == "fynapse_lines_by_source"
    r = kpis.run("adra_reconciliation_completion", std, entity_mention="Northwind", period_mention="Feb 25",
                 dimensions=["PREPARER_NAME"])
    assert r.kind == "invalid_spec" and r.code == "dimension_not_allowed"


def test_kpi_fa_draft_still_respects_data_quality(kpis, std):
    r = kpis.run("fa_invested_capital_by_group", std)
    assert r.kind == "data_quality"


def test_safe_eval():
    assert safe_eval("a / b * 100", {"a": 2, "b": 40}) == 5.0
    assert safe_eval("a / b", {"a": 1, "b": 0}) is None
    with pytest.raises(ValueError):
        safe_eval("__import__('os').system('x')", {})
