"""Spec-level golden tests: every question-bank case and the business DEV answers, run end to end
(resolve -> compile -> guard -> execute) on the local fixture. Expected values are the verified
ground truth from Databricks / the business team."""
from __future__ import annotations

import pytest

NW, CARS = "100-Northwind", "561 - Cars USA Shipping, LLC"


def rows_by(res, key_col, val_col):
    ki, vi = res.columns.index(key_col), res.columns.index(val_col)
    return {r[ki]: r[vi] for r in res.rows}


def one(res, col=None):
    assert res.kind == "answer", (res.kind, res.code, res.message, res.errors)
    assert len(res.rows) == 1, res.rows
    return res.rows[0][res.columns.index(col)] if col else res.rows[0][0]


def approx(a, b, tol=0.005):
    return a is not None and abs(float(a) - float(b)) <= tol


# ============================================================ business DEV answers (close_recon)
def test_status_103300(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "ACCOUNT_STATUS"}],
                    "entity_mention": NW, "period_mention": "Feb 25", "account": "103300"}, std)
    assert one(r) == "Approved" and r.scope_label == NW and r.period_label == "Feb 25"


def test_finalized_103300_is_false(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "IS_FINALIZED"}],
                    "entity_mention": "100-Northwind", "period_mention": "Feb 25", "account": "103300"}, std)
    assert one(r) is False


@pytest.mark.parametrize("period", ["Feb 25", "Feb 2025", "February 2025", "2025-02", "02/2025"])
def test_pending_closure_38_any_period_format(engine, std, period):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_false", "column": "IS_FINALIZED"}],
                    "entity_mention": "Northwind", "period_mention": period}, std)
    assert one(r) == 38


def test_unidentified_213130(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "UNIDENTIFIED_BALANCE"}],
                    "entity_mention": CARS, "period_mention": "Oct 26", "account": "213130"}, std)
    assert approx(one(r), -455376.16)


@pytest.mark.parametrize("mention", [CARS, "Cars USA Shipping", "561", "entity 561"])
def test_total_unidentified_abs_561_entity_names(engine, std, mention):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "sum", "column": "UNIDENTIFIED_BALANCE_ABS"}],
                    "entity_mention": mention, "period_mention": "Oct 26"}, std)
    assert approx(one(r), 22831252.26)


def test_largest_unreconciled_difference_northwind(engine, std):
    r = engine.run({"anchor": "adra_account_facts",
                    "measures": [{"op": "value", "column": "UNIDENTIFIED_BALANCE_ABS", "alias": "diff"}],
                    "dimensions": [{"column": "ACCOUNT_NUMBER"}, {"column": "ACCOUNT_NAME"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25", "order_by": "diff", "limit": 1}, std)
    assert r.kind == "answer" and r.rows[0][0] == "141111" and approx(r.rows[0][2], 992715.00)
    assert "lakehouse_mvpai.silver.adra_account_dimensions" in r.tables  # approved join was used


def test_oldest_transaction_222120(engine, std):
    r = engine.run({"anchor": "adra_transaction_facts", "measures": [{"op": "max", "column": "AGE_DAYS"}],
                    "account": "222120", "period_mention": "Feb 25"}, std)
    assert one(r) == 18 and r.scope_label == NW  # entity inferred from the account


def test_age_distribution_222120(engine, std):
    r = engine.run({"anchor": "adra_transaction_facts", "dimensions": [{"column": "AGE_GROUP"}],
                    "measures": [{"op": "count_rows", "alias": "n"}, {"op": "sum", "column": "AMOUNT_ABS", "alias": "amt"}],
                    "account": "222120", "period_mention": "Feb 25"}, std)
    assert rows_by(r, "age_group", "n") == {"0-30 Days": 2} and approx(rows_by(r, "age_group", "amt")["0-30 Days"], 9438)


def test_txn_status_153300_entity_inferred(engine, std):
    r = engine.run({"anchor": "adra_transaction_facts", "dimensions": [{"column": "TRANSACTION_STATUS"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "account": "153300", "period_mention": "Oct 26"}, std)
    assert rows_by(r, "transaction_status", "n") == {"Required adjustment": 2} and r.scope_label == CARS


def test_account_999999999_not_found(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "BALANCE"}],
                    "entity_mention": NW, "period_mention": "Feb 25", "account": "999999999"}, std)
    assert r.kind == "not_found" and r.code == "account_not_found" and "999999999" in r.message and not r.rows


# ============================================================ question bank: ADRA
def test_a01_balance(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "BALANCE"}],
                    "entity_mention": "Northwind", "period_mention": "February 2025", "account": "141111"}, std)
    assert approx(one(r), 1981646.00)


def test_a02_status(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "ACCOUNT_STATUS"}],
                    "entity_mention": "Cars USA Shipping", "period_mention": "October 2026", "account": "213130"}, std)
    assert one(r) == "Not prepared"


@pytest.mark.parametrize("ent,period,expected", [
    ("Northwind", "Feb 25", {"Approved": 7, "Not prepared": 24, "Prepared": 9}),
    ("561", "latest", {"Approved": 6, "Not prepared": 11, "Prepared": 6}),
])
def test_a04_a05_count_by_status(engine, std, ent, period, expected):
    r = engine.run({"anchor": "adra_account_facts", "dimensions": [{"column": "ACCOUNT_STATUS"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "entity_mention": ent, "period_mention": period}, std)
    assert rows_by(r, "account_status", "n") == expected


def test_a06_a07_finalized_and_share(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_true", "column": "IS_FINALIZED", "alias": "fin"},
                                                               {"op": "count_rows", "alias": "total"}],
                    "entity_mention": "561", "period_mention": "Oct 26"}, std)
    assert one(r, "fin") == 6 and one(r, "total") == 23


def test_a08_total_balance(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "sum", "column": "BALANCE"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 2025"}, std)
    assert approx(one(r), 2143711.00)


def test_a09_abs_unidentified_northwind(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "sum", "column": "UNIDENTIFIED_BALANCE_ABS"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert approx(one(r), 3940448.00)


def test_a10_top5_abs_balance(engine, std):
    r = engine.run({"anchor": "adra_account_facts",
                    "measures": [{"op": "value", "column": "BALANCE_ABS", "alias": "bal"}],
                    "dimensions": [{"column": "ACCOUNT_NUMBER"}], "entity_mention": CARS, "period_mention": "Oct 26",
                    "order_by": "bal", "limit": 5}, std)
    assert [x[0] for x in r.rows] == ["213230", "122400", "161100", "213440", "162600"]
    assert approx(r.rows[0][1], 19697737.46) and approx(r.rows[4][1], 815070.06)


def test_a11_dimension_column_auto_joined(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "dimensions": [{"column": "RISK_TYPE"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert rows_by(r, "risk_type", "n") == {"Not set": 40}


def test_a12_sum_by_recon_type(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "dimensions": [{"column": "RECONCILIATION_TYPE"}],
                    "measures": [{"op": "sum", "column": "UNIDENTIFIED_BALANCE_ABS", "alias": "amt"}],
                    "entity_mention": "561", "period_mention": "Oct 26"}, std)
    assert approx(rows_by(r, "reconciliation_type", "amt")["Bank"], 22831252.26)


def test_a13_a14_counts_and_sums_of_count_columns(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}],
                    "filters": [{"column": "NO_OF_DOCUMENTS", "op": "eq", "value": 0}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert one(r) == 40
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "sum", "column": "NO_OF_REJECTS"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert one(r) == 0


def test_a15_a16_transactions_on_account(engine, std):
    r = engine.run({"anchor": "adra_transaction_facts", "measures": [{"op": "count_rows"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25", "account": "222120"}, std)
    assert one(r) == 2
    r = engine.run({"anchor": "adra_transaction_facts", "measures": [{"op": "sum_abs", "column": "AMOUNT"}],
                    "entity_mention": "Cars USA Shipping", "period_mention": "Oct 26", "account": "153300"}, std)
    assert approx(one(r), 913.30)


def test_a17_type_is_not_status(engine, std):
    r = engine.run({"anchor": "adra_transaction_facts", "dimensions": [{"column": "TRANSACTION_TYPE"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "entity_mention": CARS, "period_mention": "Oct 26"}, std)
    assert rows_by(r, "transaction_type", "n") == {"Ledger transaction": 8, "Subledger transaction": 8}


def test_a18_a19(engine, std):
    r = engine.run({"anchor": "adra_transaction_facts", "measures": [{"op": "max", "column": "AGE_DAYS"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert one(r) == 18
    r = engine.run({"anchor": "adra_transaction_facts", "dimensions": [{"column": "AGE_GROUP"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "entity_mention": "561", "period_mention": "latest"}, std)
    assert rows_by(r, "age_group", "n") == {"0-30 Days": 16}


def test_a20_unknown_period(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "BALANCE"}],
                    "entity_mention": NW, "period_mention": "March 2023", "account": "141111"}, std)
    assert r.kind == "not_found" and r.code == "period_not_found" and "Feb 25" in r.message


def test_a21_unknown_entity(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}],
                    "entity_mention": "entity 999", "period_mention": "Feb 25"}, std)
    assert r.kind == "not_found" and r.code == "entity_not_found" and not r.rows


def test_a22_pii_masked_for_standard_visible_for_viewer(engine, std, piiv):
    spec = {"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "PREPARER_NAME"}],
            "entity_mention": "Northwind", "period_mention": "Feb 25", "account": "141111"}
    assert one(engine.run(spec, std)) == "[MASKED]"
    assert one(engine.run(spec, piiv)) == "Preparer A"


def test_a23_approver_masked_date_null(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "value", "column": "APPROVER_NAME", "alias": "approver"},
                                                               {"op": "value", "column": "APPROVED_DATE", "alias": "approved"}],
                    "entity_mention": CARS, "period_mention": "Oct 26", "account": "213130"}, std)
    assert one(r, "approver") == "[MASKED]" and one(r, "approved") is None


def test_a24_compare_previous_without_data(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_true", "column": "IS_FINALIZED"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25", "period_policy": "compare_previous"}, std)
    assert r.kind == "cannot_compare" and not r.rows


def test_a25_two_filters_anded(engine, std):
    r = engine.run({"anchor": "adra_account_facts", "measures": [{"op": "count_rows"}],
                    "filters": [{"column": "ACCOUNT_STATUS", "op": "eq", "value": "approved"},
                                {"column": "IS_FINALIZED", "op": "is_false"}],
                    "entity_mention": "Northwind", "period_mention": "Feb 25"}, std)
    assert one(r) == 5


# ============================================================ question bank: Fynapse
def test_f01_by_entity(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "PARENT_ENTITY"}],
                    "measures": [{"op": "count_rows", "alias": "lines"}, {"op": "sum", "column": "REPORTING_AMOUNT", "alias": "net"}]}, std)
    assert rows_by(r, "parent_entity", "lines") == {"UK03": 283, "UK06": 28, "UK07": 280, "UK13": 16, "UK14": 52, "UK17": 158}
    nets = rows_by(r, "parent_entity", "net")
    assert approx(nets["UK03"], -0.03) and approx(nets["UK17"], -0.02) and approx(nets["UK06"], 0)


def test_f02_by_period(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "__period__"}],
                    "measures": [{"op": "count_rows", "alias": "lines"}, {"op": "sum", "column": "REPORTING_AMOUNT", "alias": "net"}]}, std)
    assert rows_by(r, "period", "lines") == {"FY2026 P8": 207, "FY2026 P9": 610}
    assert approx(rows_by(r, "period", "net")["FY2026 P9"], -0.06)


@pytest.mark.parametrize("period", ["Sep 26", "September 2026", "2026-09", "FY2026 P9"])
def test_f03_period_filter(engine, std, period):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "JOURNAL_TYPE"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "period_mention": period}, std)
    assert rows_by(r, "journal_type", "n") == {"PERM": 610}


def test_f04_top5_gross_for_uk03(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "ACCOUNT"}],
                    "measures": [{"op": "sum_abs", "column": "REPORTING_AMOUNT", "alias": "gross"}],
                    "entity_mention": "UK03 subledger", "order_by": "gross", "limit": 5}, std)
    assert [x[0] for x in r.rows] == ["199001", "239001", "109035", "105203", "430000"]
    assert approx(r.rows[0][1], 70996898.63) and approx(r.rows[4][1], 4409112.86)


def test_f05_f16_currencies(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "TRANSACTION_CURRENCY"}],
                    "measures": [{"op": "count_rows", "alias": "n"}, {"op": "sum", "column": "TRANSACTION_AMOUNT", "alias": "amt"}]}, std)
    assert rows_by(r, "transaction_currency", "n") == {"USD": 360, "GBP": 238, "EUR": 120, "CAD": 60, "SEK": 17,
                                                       "AUD": 14, "NOK": 4, "ZAR": 4}
    assert all(approx(v, 0) for v in rows_by(r, "transaction_currency", "amt").values())
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "FUNCTIONAL_CURRENCY"}],
                    "measures": [{"op": "sum", "column": "FUNCTIONAL_AMOUNT", "alias": "amt"}]}, std)
    assert set(rows_by(r, "functional_currency", "amt")) == {"EUR", "GBP"}


def test_f06_f07_entity_and_period(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}], "entity_mention": "UK07"}, std)
    assert one(r) == 280
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "sum", "column": "REPORTING_AMOUNT"}],
                    "entity_mention": "UK17", "period_mention": "Aug 2026"}, std)
    assert approx(one(r), -0.02)


def test_f08_count_distinct(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_distinct", "column": "JOURNAL_ID"}],
                    "period_mention": "Sep 26"}, std)
    assert one(r) == 205


def test_f09_f12_null_checks(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}],
                    "filters": [{"column": "REVERSES", "op": "not_null"}]}, std)
    assert one(r) == 0
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}],
                    "filters": [{"column": "CHILD_ENTITY", "op": "is_null"}]}, std)
    assert one(r) == 384


def test_f10_top_events(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "BUSINESS_EVENT"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "limit": 5}, std)
    assert [x[1] for x in r.rows] == [433, 214, 170]


def test_f11_share(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "PARENT_ENTITY"}],
                    "measures": [{"op": "count_rows", "alias": "lines"}], "share_of_total": True}, std)
    shares = {k: round(v, 1) for k, v in rows_by(r, "parent_entity", "lines_share_pct").items()}
    assert shares == {"UK03": 34.6, "UK06": 3.4, "UK07": 34.3, "UK13": 2.0, "UK14": 6.4, "UK17": 19.3}


def test_f13_empty_lob(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "LOB"}],
                    "measures": [{"op": "count_rows", "alias": "n"}], "limit": 5}, std)
    assert r.rows == [[None, 817]]


def test_f14_compare_previous(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows", "alias": "lines"}],
                    "period_mention": "Sep 2026", "period_policy": "compare_previous"}, std)
    assert rows_by(r, "period", "lines") == {"FY2026 P8": 207, "FY2026 P9": 610}


def test_f15_unknown_entity(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "measures": [{"op": "count_rows"}], "entity_mention": "UK99"}, std)
    assert r.kind == "not_found" and r.code == "entity_not_found"


def test_fynapse_business_answer_dev_xdom_10(engine, std):
    r = engine.run({"anchor": "fact_fynapse_slr_journals", "dimensions": [{"column": "SOURCE_SYSTEM"}],
                    "measures": [{"op": "count_rows", "alias": "lines"}, {"op": "sum", "column": "REPORTING_AMOUNT", "alias": "net"}],
                    "share_of_total": True, "order_by": "lines"}, std)
    assert rows_by(r, "source_system", "lines") == {"NOVIDEA": 433, "ACCRUAL": 214, "Concur": 170}
    assert {k: round(v, 1) for k, v in rows_by(r, "source_system", "lines_share_pct").items()} == \
        {"NOVIDEA": 53.0, "ACCRUAL": 26.2, "Concur": 20.8}
    assert approx(sum(rows_by(r, "source_system", "net").values()), -0.08)
    assert "net_share_pct" not in r.columns  # share hidden for signed amounts
