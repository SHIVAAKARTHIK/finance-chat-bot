import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "fixtures"))

from build_fixture import build  # noqa: E402
from fincore.access.models import YamlAccessProvider  # noqa: E402
from fincore.exec.duckdb_exec import DuckDBExecutor  # noqa: E402
from fincore.query.engine import SemanticEngine  # noqa: E402
from fincore.semantic.catalog import Catalog  # noqa: E402


@pytest.fixture(scope="session")
def con():
    return build()


@pytest.fixture(scope="session")
def catalog():
    return Catalog.load(ROOT / "config")


@pytest.fixture(scope="session")
def access():
    return YamlAccessProvider(ROOT / "config" / "access.example.yaml")


@pytest.fixture()
def engine(catalog, con):
    return SemanticEngine(catalog, DuckDBExecutor(con=con))


@pytest.fixture(scope="session")
def std(access):
    return access.user_context("TEST_standard")


@pytest.fixture(scope="session")
def piiv(access):
    return access.user_context("TEST_pii_viewer")
