"""Low-level SQL expression helpers (sqlglot). Identifiers come only from the catalog; values are
always literals built by sqlglot (escaped per dialect)."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlglot import exp

from ..semantic.models import Column

TRUE_WORDS = ("true", "t", "yes", "y", "1")
FALSE_WORDS = ("false", "f", "no", "n", "0")


def col(alias: str, name: str) -> exp.Column:
    return exp.column(name, table=alias, quoted=True)


def lit(v: Any) -> exp.Expression:
    if v is None:
        return exp.null()
    if isinstance(v, bool):
        return exp.true() if v else exp.false()
    if isinstance(v, (int, float, Decimal)):
        return exp.Literal.number(str(v))
    if isinstance(v, date):
        return exp.cast(exp.Literal.string(v.isoformat()), "DATE")
    return exp.Literal.string(str(v))


def to_number(v: Any) -> Decimal | None:
    try:
        return Decimal(str(v).replace(",", "").strip())
    except (InvalidOperation, AttributeError):
        return None


def typed(alias: str, c: Column) -> exp.Expression:
    """Column expression in its logical type (casting from string storage when needed)."""
    base = col(alias, c.name)
    if c.physical == c.type:
        return base
    if c.physical != "string":
        return exp.cast(base, {"string": "VARCHAR", "decimal": "DECIMAL(38, 6)", "integer": "BIGINT",
                               "date": "DATE", "timestamp": "TIMESTAMP", "boolean": "BOOLEAN"}[c.type])
    trimmed = exp.Trim(this=base)
    if c.type == "decimal":
        return exp.TryCast(this=exp.func("replace", trimmed, exp.Literal.string(","), exp.Literal.string("")),
                           to=exp.DataType.build("DECIMAL(38, 6)"))
    if c.type == "integer":
        return exp.TryCast(this=exp.TryCast(this=trimmed, to=exp.DataType.build("DECIMAL(38, 6)")),
                           to=exp.DataType.build("BIGINT"))
    if c.type == "timestamp":
        return exp.TryCast(this=trimmed, to=exp.DataType.build("TIMESTAMP"))
    if c.type == "date":
        return exp.cast(exp.TryCast(this=trimmed, to=exp.DataType.build("TIMESTAMP")), "DATE")
    if c.type == "boolean":
        low = exp.Lower(this=trimmed)
        return (exp.Case()
                .when(exp.In(this=low, expressions=[lit(w) for w in TRUE_WORDS]), exp.true())
                .when(exp.In(this=low, expressions=[lit(w) for w in FALSE_WORDS]), exp.false())
                .else_(exp.null()))
    return trimmed


def norm_text(e: exp.Expression) -> exp.Expression:
    return exp.Lower(this=exp.Trim(this=exp.cast(e, "VARCHAR")))


def text_eq(e: exp.Expression, value: str) -> exp.Expression:
    return exp.EQ(this=norm_text(e), expression=lit(str(value).strip().lower()))


def is_blank(e: exp.Expression, c: Column) -> exp.Expression:
    if c.type == "string":
        return exp.or_(exp.Is(this=e, expression=exp.null()), exp.EQ(this=exp.Trim(this=e), expression=lit("")))
    return exp.Is(this=e, expression=exp.null())


def and_all(conds: list[exp.Expression]) -> exp.Expression | None:
    conds = [c for c in conds if c is not None]
    if not conds:
        return None
    return exp.and_(*conds) if len(conds) > 1 else conds[0]


def or_all(conds: list[exp.Expression]) -> exp.Expression | None:
    conds = [c for c in conds if c is not None]
    if not conds:
        return None
    return exp.or_(*conds) if len(conds) > 1 else conds[0]


def paren(e: exp.Expression) -> exp.Expression:
    return exp.Paren(this=e)


def table_ref(fqn: str, alias: str) -> exp.Expression:
    return exp.alias_(exp.to_table(fqn), alias, table=True)


def scope_predicate(alias: str, scope_columns: dict[str, str], scopes: list[dict[str, str]]) -> exp.Expression:
    """OR over authorized scopes of AND(column = value). Empty scopes -> FALSE (fail closed)."""
    ors = []
    for s in scopes:
        ands = []
        for key, column in scope_columns.items():
            if key not in s:
                ands = []
                break
            ands.append(exp.EQ(this=exp.Trim(this=exp.cast(col(alias, column), "VARCHAR")),
                               expression=lit(str(s[key]).strip())))
        if ands:
            ors.append(paren(and_all(ands)))
    return paren(or_all(ors)) if ors else exp.false()
