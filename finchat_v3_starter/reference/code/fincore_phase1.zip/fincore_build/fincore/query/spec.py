"""QuerySpec: what the model (or a KPI definition) asks for. Never SQL."""
from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

MeasureOp = Literal["value", "count_rows", "count", "count_distinct", "sum", "sum_abs", "avg", "min", "max",
                    "count_true", "count_false"]
FilterOp = Literal["eq", "ne", "in", "not_in", "gt", "gte", "lt", "lte", "is_null", "not_null",
                   "contains", "not_contains", "is_true", "is_false"]
PeriodPolicy = Literal["default", "explicit", "latest", "all", "compare_previous"]
PERIOD_PSEUDO = "__period__"

_ALIAS_RE = re.compile(r"[^a-z0-9_]+")


def safe_alias(text: str) -> str:
    a = _ALIAS_RE.sub("_", (text or "").lower()).strip("_")
    if not a or a[0].isdigit():
        a = f"c_{a}"
    return a[:60]


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Measure(_M):
    op: MeasureOp = Field(alias="operation")
    column: str | None = None  # None only for count_rows
    table: str | None = None  # defaults to the anchor
    alias: str | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    @model_validator(mode="after")
    def _norm(self) -> "Measure":
        if self.op == "count" and not self.column:
            self.op = "count_rows"
        if self.op != "count_rows" and not self.column:
            raise ValueError(f"measure op {self.op} needs a column")
        if not self.alias:
            base = self.op if self.op == "count_rows" else f"{self.op}_{self.column}"
            self.alias = base
        self.alias = safe_alias(self.alias)
        return self


class Dimension(_M):
    column: str
    table: str | None = None
    alias: str | None = None

    @model_validator(mode="after")
    def _norm(self) -> "Dimension":
        self.alias = safe_alias(self.alias or ("period" if self.column == PERIOD_PSEUDO else self.column))
        return self


class Filter(_M):
    column: str
    op: FilterOp = "eq"
    value: Any = None
    table: str | None = None


class OrderBy(_M):
    by: str
    descending: bool = True

    @field_validator("by")
    @classmethod
    def _by(cls, v: str) -> str:
        return safe_alias(v)


class QuerySpec(_M):
    anchor: str
    measures: list[Measure] = Field(default_factory=list)
    dimensions: list[Dimension] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    entity_mention: str | None = None
    period_mention: str | None = None
    period_policy: PeriodPolicy = "default"
    identifiers: dict[str, str] = Field(default_factory=dict)  # e.g. {"account": "103300"}
    account: str | None = None  # shortcut for identifiers["account"]
    order_by: list[OrderBy] = Field(default_factory=list)
    limit: int | None = None
    share_of_total: bool = False
    join_recipe_ids: list[str] = Field(default_factory=list)  # optional; engine plans approved joins itself
    clarification: str | None = None  # model may ask instead of querying

    @field_validator("order_by", mode="before")
    @classmethod
    def _order(cls, v):
        if isinstance(v, str):
            return [{"by": v}]
        if isinstance(v, dict):
            return [v]
        return v or []

    @model_validator(mode="after")
    def _norm(self) -> "QuerySpec":
        if self.account and "account" not in self.identifiers:
            self.identifiers["account"] = self.account
        self.identifiers = {k.lower(): str(v).strip() for k, v in self.identifiers.items() if str(v).strip()}
        if self.limit is not None:
            self.limit = max(1, min(int(self.limit), 500))
        if not self.measures and not self.dimensions and not self.clarification:
            raise ValueError("spec needs at least one measure or dimension")
        aliases = [m.alias for m in self.measures] + [d.alias for d in self.dimensions]
        if len(aliases) != len(set(aliases)):
            raise ValueError(f"duplicate output aliases: {aliases}")
        ops = {m.op for m in self.measures}
        if "value" in ops and ops - {"value"}:
            raise ValueError("'value' measures cannot be mixed with aggregates")
        return self

    @property
    def is_lookup(self) -> bool:
        return bool(self.measures) and all(m.op == "value" for m in self.measures)
