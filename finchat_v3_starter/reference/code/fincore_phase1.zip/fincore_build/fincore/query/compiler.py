"""Compile a resolved query into SQL. Deterministic: same input -> same SQL."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

import sqlglot
from sqlglot import exp

from ..semantic.models import Column, JoinRecipe, Table
from . import sqlbuild as sb
from .spec import PERIOD_PSEUDO, Filter, OrderBy, QuerySpec

MASK = "[MASKED]"


class CompileError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass
class PeriodFilter:
    mode: str  # dimension | columns | date | none
    ids: list[str] = field(default_factory=list)  # dimension mode
    pairs: list[tuple[int, int]] = field(default_factory=list)  # columns mode
    start: date | None = None  # date mode (inclusive)
    end: date | None = None  # date mode (exclusive)


@dataclass
class ResolvedQuery:
    spec: QuerySpec
    anchor: Table
    scopes: list[dict[str, str]]
    period: PeriodFilter | None
    joins: list[tuple[JoinRecipe, Table, str]]  # recipe, target table, alias
    identifier_filters: list[tuple[str, Column, str]]  # alias, column, value
    can_view_pii: bool
    max_rows: int = 200
    period_table: Table | None = None  # dimension-mode period dim (joined when a period column is needed)


class Compiler:
    ANCHOR = "f"
    PERIOD = "p"

    def __init__(self, rq: ResolvedQuery):
        self.rq = rq
        self.aliases: dict[str, tuple[str, Table]] = {rq.anchor.name: (self.ANCHOR, rq.anchor)}
        for recipe, t, a in rq.joins:
            self.aliases[t.name] = (a, t)
        self.need_period_join = False

    # ------------------------------------------------------------------ helpers
    def _resolve_col(self, name: str, table: str | None) -> tuple[str, Column, Table]:
        if table and table not in self.aliases:
            raise CompileError("join_unapproved", f"table {table} is not joined to {self.rq.anchor.name}")
        candidates = [self.aliases[table]] if table else list(self.aliases.values())
        for alias, t in candidates:
            c = t.column(name)
            if c:
                return alias, c, t
        raise CompileError("unknown_column", f"unknown column {name}")

    def _period_label_expr(self) -> exp.Expression:
        pb = self.rq.anchor.period
        if pb.mode == "dimension":
            self.need_period_join = True
            pt = self.rq.period_table
            if pb.label_column:
                return sb.typed(self.PERIOD, pt.column(pb.label_column))
            return sb.typed(self.PERIOD, pt.column(pb.date_column))
        if pb.mode == "columns":
            parts: list[exp.Expression] = [sb.lit("FY")]
            a = self.rq.anchor
            parts.append(exp.cast(sb.typed(self.ANCHOR, a.column(pb.columns[0])), "VARCHAR"))
            for c in pb.columns[1:]:
                parts += [sb.lit(" P"), exp.cast(sb.typed(self.ANCHOR, a.column(c)), "VARCHAR")]
            return exp.func("concat", *parts)
        if pb.mode == "date":
            d = sb.typed(self.ANCHOR, self.rq.anchor.column(pb.date_column))
            return exp.cast(exp.func("date_trunc", sb.lit("month"), d), "DATE")
        raise CompileError("period_binding_missing", f"{self.rq.anchor.name} has no period binding")

    def _value_expr(self, alias: str, c: Column) -> exp.Expression:
        if c.pii and not self.rq.can_view_pii:
            return sb.lit(MASK)
        return sb.typed(alias, c)

    def _measure_expr(self, m) -> exp.Expression:
        if m.op == "count_rows":
            return exp.Count(this=exp.Star())
        alias, c, _ = self._resolve_col(m.column, m.table)
        if c.pii and not self.rq.can_view_pii and m.op != "value":
            raise CompileError("pii_restricted", f"{c.name} is restricted for this user")
        e = sb.typed(alias, c)
        if m.op == "value":
            return self._value_expr(alias, c)
        if m.op == "count":
            return exp.Count(this=e)
        if m.op == "count_distinct":
            return exp.Count(this=exp.Distinct(expressions=[e]))
        if m.op in ("sum", "sum_abs", "avg"):
            if c.type not in ("decimal", "integer"):
                raise CompileError("bad_measure", f"{m.op} needs a numeric column, {c.name} is {c.type}")
            inner = exp.Abs(this=e) if m.op == "sum_abs" else e
            return exp.Sum(this=inner) if m.op != "avg" else exp.Avg(this=inner)
        if m.op in ("min", "max"):
            return exp.Min(this=e) if m.op == "min" else exp.Max(this=e)
        if m.op in ("count_true", "count_false"):
            if c.type != "boolean":
                raise CompileError("bad_measure", f"{m.op} needs a yes/no column, {c.name} is {c.type}")
            cond = e if m.op == "count_true" else exp.Not(this=e)
            return exp.Sum(this=exp.Case().when(cond, sb.lit(1)).else_(sb.lit(0)))
        raise CompileError("bad_measure", f"unsupported op {m.op}")

    def _filter_expr(self, f: Filter) -> exp.Expression:
        alias, c, _ = self._resolve_col(f.column, f.table)
        if c.pii and not self.rq.can_view_pii:
            raise CompileError("pii_restricted", f"filtering on {c.name} is restricted for this user")
        e = sb.typed(alias, c)
        op, v = f.op, f.value
        if op == "is_null":
            return sb.paren(sb.is_blank(e, c))
        if op == "not_null":
            return exp.Not(this=sb.paren(sb.is_blank(e, c)))
        if c.type == "boolean" or op in ("is_true", "is_false"):
            want = op == "is_true" or (op == "eq" and str(v).strip().lower() in sb.TRUE_WORDS)
            if op == "ne":
                want = str(v).strip().lower() not in sb.TRUE_WORDS
            return exp.EQ(this=e, expression=exp.true() if want else exp.false())
        if c.type == "string":
            vals = v if isinstance(v, list) else [v]
            if op in ("eq", "in"):
                return sb.paren(sb.or_all([sb.text_eq(e, x) for x in vals]))
            if op in ("ne", "not_in"):
                return exp.Not(this=sb.paren(sb.or_all([sb.text_eq(e, x) for x in vals])))
            if op in ("contains", "not_contains"):
                pat = "%" + str(v).strip().lower().replace("%", "").replace("_", "") + "%"
                like = exp.Like(this=sb.norm_text(e), expression=sb.lit(pat))
                return like if op == "contains" else exp.Not(this=like)
            raise CompileError("bad_filter", f"operator {op} not valid for text column {c.name}")
        if c.type in ("decimal", "integer"):
            vals = v if isinstance(v, list) else [v]
            nums = [sb.to_number(x) for x in vals]
            if any(n is None for n in nums):
                raise CompileError("bad_filter", f"{c.name} needs numeric values, got {v!r}")
            lits = [sb.lit(n) for n in nums]
            if op in ("in", "not_in"):
                ine = exp.In(this=e, expressions=lits)
                return ine if op == "in" else exp.Not(this=ine)
            cmp = {"eq": exp.EQ, "ne": exp.NEQ, "gt": exp.GT, "gte": exp.GTE, "lt": exp.LT, "lte": exp.LTE}.get(op)
            if not cmp:
                raise CompileError("bad_filter", f"operator {op} not valid for number column {c.name}")
            return cmp(this=e, expression=lits[0])
        if c.type in ("date", "timestamp"):
            try:
                d = date.fromisoformat(str(v)[:10])
            except ValueError:
                raise CompileError("bad_filter", f"{c.name} needs a date (YYYY-MM-DD), got {v!r}") from None
            cmp = {"eq": exp.EQ, "ne": exp.NEQ, "gt": exp.GT, "gte": exp.GTE, "lt": exp.LT, "lte": exp.LTE}.get(op)
            if not cmp:
                raise CompileError("bad_filter", f"operator {op} not valid for date column {c.name}")
            return cmp(this=exp.cast(e, "DATE"), expression=sb.lit(d))
        raise CompileError("bad_filter", f"cannot filter {c.name}")

    def _period_predicate(self) -> exp.Expression | None:
        pf = self.rq.period
        if not pf or pf.mode == "none":
            return None
        a = self.rq.anchor
        pb = a.period
        if pf.mode == "dimension":
            if not pf.ids:
                return exp.false()
            return exp.In(this=exp.Trim(this=exp.cast(sb.col(self.ANCHOR, pb.id_column), "VARCHAR")),
                          expressions=[sb.lit(i) for i in pf.ids])
        if pf.mode == "columns":
            ors = []
            for pair in pf.pairs:
                ands = [exp.EQ(this=sb.typed(self.ANCHOR, a.column(cn)), expression=sb.lit(int(v)))
                        for cn, v in zip(pb.columns, pair)]
                ors.append(sb.paren(sb.and_all(ands)))
            return sb.paren(sb.or_all(ors)) if ors else exp.false()
        if pf.mode == "date":
            d = exp.cast(sb.typed(self.ANCHOR, a.column(pb.date_column)), "DATE")
            return sb.and_all([exp.GTE(this=d, expression=sb.lit(pf.start)), exp.LT(this=d, expression=sb.lit(pf.end))])
        return None

    def _anchor_source(self) -> exp.Expression:
        a = self.rq.anchor
        if not a.current_row_rule:
            return sb.table_ref(a.fqn, self.ANCHOR)
        r = a.current_row_rule
        rn = exp.Window(this=exp.RowNumber(),
                        partition_by=[exp.column(c, quoted=True) for c in r.partition_by],
                        order=exp.Order(expressions=[exp.Ordered(this=exp.column(r.order_by, quoted=True),
                                                                 desc=r.descending)]))
        inner = (sqlglot.select(exp.Star(), exp.alias_(rn, "__rn", quoted=True))
                 .from_(sb.table_ref(a.fqn, "t")))
        outer = sqlglot.select(exp.Star()).from_(inner.subquery("v")).where(
            exp.EQ(this=exp.column("__rn", quoted=True), expression=sb.lit(1)))
        return outer.subquery(self.ANCHOR)

    # ------------------------------------------------------------------ main
    def build(self) -> tuple[exp.Select, list[str]]:
        rq, spec = self.rq, self.rq.spec
        a = rq.anchor
        selects: list[exp.Expression] = []
        groups: list[exp.Expression] = []
        out_cols: list[str] = []

        for d in spec.dimensions:
            if d.column == PERIOD_PSEUDO:
                e = self._period_label_expr()
            else:
                alias, c, _ = self._resolve_col(d.column, d.table)
                if c.pii and not rq.can_view_pii:
                    raise CompileError("pii_restricted", f"grouping by {c.name} is restricted for this user")
                e = sb.typed(alias, c)
            selects.append(exp.alias_(e, d.alias, quoted=True))
            if not spec.is_lookup:
                groups.append(e)
            out_cols.append(d.alias)
        for m in spec.measures:
            selects.append(exp.alias_(self._measure_expr(m), m.alias, quoted=True))
            out_cols.append(m.alias)

        where = [sb.scope_predicate(self.ANCHOR, a.entity_scope.columns, rq.scopes)] if a.entity_scope else []
        pp = self._period_predicate()
        if pp is not None:
            where.append(pp)
        for alias, c, value in rq.identifier_filters:
            where.append(sb.text_eq(sb.typed(alias, c), value))
        for f in spec.filters:
            where.append(self._filter_expr(f))

        q = sqlglot.select(*selects).from_(self._anchor_source())
        for recipe, t, alias in rq.joins:
            on = sb.and_all([exp.EQ(this=sb.col(self.ANCHOR, l), expression=sb.col(alias, r)) for l, r in recipe.on])
            q = q.join(sb.table_ref(t.fqn, alias), on=on, join_type="left")
        if self.need_period_join:
            pb, pt = a.period, rq.period_table
            conds = [exp.EQ(this=sb.col(self.ANCHOR, pb.id_column), expression=sb.col(self.PERIOD, pb.dim_id_column))]
            for key, dim_col in pb.dim_scope_columns.items():
                conds.append(exp.EQ(this=sb.col(self.ANCHOR, a.entity_scope.columns[key]), expression=sb.col(self.PERIOD, dim_col)))
            q = q.join(sb.table_ref(pt.fqn, self.PERIOD), on=sb.and_all(conds), join_type="left")
        w = sb.and_all(where)
        if w is not None:
            q = q.where(w)
        if groups:
            q = q.group_by(*groups)

        order = list(spec.order_by)
        if not order and spec.limit and spec.measures and not spec.is_lookup:
            order = [OrderBy(by=spec.measures[0].alias, descending=True)]
        limit = min(spec.limit or rq.max_rows, rq.max_rows)

        share_aliases = [m.alias for m in spec.measures if spec.share_of_total and m.op in
                         ("count_rows", "count", "count_distinct", "sum", "sum_abs", "count_true", "count_false")]
        if share_aliases:
            inner = q.subquery("q")
            outs: list[exp.Expression] = [exp.column(c, table="q", quoted=True) for c in out_cols]
            for s in share_aliases:
                tot = exp.Window(this=exp.Sum(this=exp.column(s, table="q", quoted=True)))
                share = (exp.Case().when(exp.EQ(this=tot, expression=sb.lit(0)), exp.null())
                         .else_(exp.Div(this=exp.Mul(this=exp.column(s, table="q", quoted=True), expression=sb.lit(100.0)),
                                        expression=tot.copy())))
                outs.append(exp.alias_(share, f"{s}_share_pct", quoted=True))
                out_cols.append(f"{s}_share_pct")
            q = sqlglot.select(*outs).from_(inner)
        known = set(out_cols)
        ords = []
        for o in order:
            if o.by not in known:
                raise CompileError("bad_order", f"order_by {o.by} is not an output column ({sorted(known)})")
            ords.append(exp.Ordered(this=exp.to_identifier(o.by, quoted=True), desc=o.descending))
        if not ords and groups:
            ords = [exp.Ordered(this=exp.to_identifier(d.alias, quoted=True)) for d in spec.dimensions]
        if ords:
            q = q.order_by(*ords)
        q = q.limit(limit)
        return q, out_cols

    def sql(self, dialect: str) -> tuple[str, list[str]]:
        q, cols = self.build()
        return q.sql(dialect=dialect), cols
