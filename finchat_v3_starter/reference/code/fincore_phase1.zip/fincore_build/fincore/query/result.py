"""QueryResult: the single outcome type for every query (silver spec or KPI)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

ResultKind = Literal[
    "answer", "not_found", "clarify", "cannot_compare", "pii_restricted", "access_denied",
    "domain_not_enabled", "data_quality", "invalid_spec", "timeout", "error",
]


@dataclass
class QueryResult:
    kind: ResultKind
    columns: list[str] = field(default_factory=list)
    rows: list[list[Any]] = field(default_factory=list)
    message: str = ""
    code: str = ""  # machine reason, e.g. entity_not_found, period_not_found, join_unapproved
    options: list[str] = field(default_factory=list)  # clarify choices
    scope_label: str = ""
    period_label: str = ""
    tables: list[str] = field(default_factory=list)
    sql_rendered: str = ""
    source: Literal["semantic_silver", "kpi"] = "semantic_silver"
    notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)  # spec problems the model can fix
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.kind == "answer"

    def as_dict(self) -> dict[str, Any]:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}
