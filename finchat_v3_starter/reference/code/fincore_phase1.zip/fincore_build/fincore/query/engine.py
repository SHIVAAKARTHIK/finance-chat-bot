"""SemanticEngine: spec -> validate -> resolve (entity, period, identifiers) -> plan joins ->
data-quality checks -> compile -> guard -> execute -> QueryResult.

The engine is the only component that touches data. Every path is scoped to the user.
"""
from __future__ import annotations

import time
from datetime import date
from typing import Any

from pydantic import ValidationError

from ..access.models import UserContext
from ..exec.base import ExecutionError, Executor
from ..semantic.catalog import Catalog
from ..semantic.models import JoinRecipe, Table
from .compiler import CompileError, Compiler, PeriodFilter, ResolvedQuery
from .guard import check_sql
from .lookup import EntityLabel, Lookup, PeriodOption
from .result import QueryResult
from .spec import PERIOD_PSEUDO, Dimension, QuerySpec
from .text import mention_tokens, norm_tokens, parse_period


def _fmt_validation(e: ValidationError) -> list[str]:
    out = []
    for err in e.errors():
        loc = ".".join(str(x) for x in err.get("loc", ()))
        out.append(f"{loc}: {err.get('msg')}" if loc else str(err.get("msg")))
    return out


def match_entities(mention: str, labels: list[EntityLabel]) -> list[EntityLabel]:
    """Code/name matching that ignores punctuation, company suffixes (LLC, Inc ...) and noise words.

    Tiers (first non-empty wins): exact code/name/label; code token present in the mention;
    all mention tokens inside the entity's tokens; the entity's full name inside the mention.
    """
    m_toks = mention_tokens(mention)
    if not m_toks:
        return []
    m_set, m_str = set(m_toks), " ".join(m_toks)
    exact, by_code, subset, contains = [], [], [], []
    for e in labels:
        code = " ".join(norm_tokens(e.code))
        name_toks = [t for t in norm_tokens(e.name) if t not in set(norm_tokens(e.code))]
        all_toks = set(norm_tokens(e.code)) | set(norm_tokens(e.name))
        if m_str in {code, " ".join(norm_tokens(e.name)), " ".join(norm_tokens(e.label)), " ".join(name_toks)}:
            exact.append(e)
        elif code and code in m_set:
            by_code.append(e)
        elif m_set <= all_toks:
            subset.append(e)
        elif name_toks and set(name_toks) <= m_set:
            contains.append(e)
    return exact or by_code or subset or contains


class SemanticEngine:
    def __init__(self, catalog: Catalog, executor: Executor, lookup: Lookup | None = None, max_rows: int = 200,
                 query_timeout_s: float = 30.0):
        self.catalog = catalog
        self.ex = executor
        self.lookup = lookup or Lookup(catalog, executor)
        self.max_rows = max_rows
        self.timeout = query_timeout_s

    # ================================================================== public
    def run(self, spec: QuerySpec | dict[str, Any], user: UserContext) -> QueryResult:
        t0 = time.perf_counter()
        try:
            res = self._run(spec, user)
        except ExecutionError as e:
            res = QueryResult("timeout" if e.timeout else "error", message="The data query failed.", code="query_failed",
                              errors=[str(e)])
        res.meta["elapsed_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return res

    # ================================================================== steps
    def _run(self, spec_in, user: UserContext) -> QueryResult:
        try:
            spec = spec_in if isinstance(spec_in, QuerySpec) else QuerySpec(**spec_in)
        except ValidationError as e:
            return QueryResult("invalid_spec", message="The query spec is invalid.", code="invalid_spec",
                               errors=_fmt_validation(e))
        except TypeError as e:
            return QueryResult("invalid_spec", message="The query spec is invalid.", code="invalid_spec", errors=[str(e)])
        if spec.clarification:
            return QueryResult("clarify", message=spec.clarification, code="model_clarification")

        anchor = self.catalog.table(spec.anchor)
        if not anchor or not anchor.queryable:
            return QueryResult("invalid_spec", code="unknown_table", message=f"Unknown table {spec.anchor}.",
                               errors=[f"anchor {spec.anchor} is not a queryable table"])
        domain = self.catalog.domains[anchor.domain]
        if not domain.enabled:
            return QueryResult("domain_not_enabled", code="domain_not_enabled",
                               message=f"{domain.title or domain.name} data is not enabled yet.")
        if not user.can_use_domain(domain.name) or not user.can_read_table(anchor.fqn):
            return QueryResult("access_denied", code="table_access", message="You don't have access to this data.")
        scopes = list(user.scopes_for(domain.name)) if anchor.entity_scope else []
        if anchor.entity_scope and not scopes:
            return QueryResult("access_denied", code="no_entity_scope",
                               message="You don't have access to any entity for this data.")

        # ---- joins and column placement
        try:
            joins, spec = self._plan_joins(anchor, spec, user)
        except CompileError as e:
            kind = "access_denied" if e.code == "table_access" else "invalid_spec"
            return QueryResult(kind, code=e.code, message=str(e), errors=[str(e)])

        # ---- entity
        ent = self._resolve_entity(anchor, domain, spec, scopes, joins)
        if isinstance(ent, QueryResult):
            return ent
        resolved_scopes, scope_label = ent

        # ---- period
        notes: list[str] = []
        per = self._resolve_period(anchor, spec, resolved_scopes, notes)
        if isinstance(per, QueryResult):
            per.scope_label = scope_label
            return per
        period_filter, period_label, spec = per

        # ---- identifiers
        ident_filters = []
        for name, value in spec.identifiers.items():
            b = anchor.identifiers.get(name)
            if not b:
                return QueryResult("invalid_spec", code="unknown_identifier",
                                   message=f"{anchor.name} has no identifier '{name}'.",
                                   errors=[f"identifier {name} unknown; known: {sorted(anchor.identifiers)}"])
            alias, tbl = "f", anchor
            if b.table:
                hit = [(a, t) for r, t, a in joins if t.name == b.table]
                alias, tbl = hit[0]
            ident_filters.append((alias, tbl.column(b.column), value))

        # ---- data quality: grain uniqueness of the anchor and of joined dimensions on their join keys
        if anchor.grain_check and anchor.grain:
            dups = self.lookup.grain_duplicates(anchor, resolved_scopes)
            if dups > 0:
                return QueryResult("data_quality", code="grain_not_unique", scope_label=scope_label,
                                   message=(f"The source table {anchor.name} has {dups} duplicate rows at its declared "
                                            f"grain ({', '.join(anchor.grain)}), so the answer is withheld to avoid "
                                            f"double counting. Please report this to the data team."))
        for recipe, t, _ in joins:
            if t.grain_check:
                dim_scopes = resolved_scopes if t.entity_scope else []
                dups = self.lookup.grain_duplicates(t, dim_scopes, [r for _, r in recipe.on])
                if dups > 0:
                    return QueryResult("data_quality", code="join_fanout", scope_label=scope_label,
                                       message=f"Joining {t.name} would duplicate rows ({dups}); answer withheld.")

        # ---- compile, guard, execute
        rq = ResolvedQuery(spec, anchor, resolved_scopes, period_filter, joins, ident_filters, user.can_view_pii,
                           self.max_rows, self.catalog.tables.get(anchor.period.table) if anchor.period.table else None)
        try:
            sql, out_cols = Compiler(rq).sql(self.ex.dialect)
        except CompileError as e:
            kind = "pii_restricted" if e.code == "pii_restricted" else "invalid_spec"
            return QueryResult(kind, code=e.code, message=str(e), errors=[str(e)], scope_label=scope_label,
                               period_label=period_label)
        allowed = {anchor.fqn} | {t.fqn for _, t, _ in joins} | ({rq.period_table.fqn} if rq.period_table else set())
        problems = check_sql(sql, self.ex.dialect, allowed)
        if problems:
            return QueryResult("error", code="guard_rejected", message="The query was blocked by the safety check.",
                               errors=problems)
        res = self.ex.execute(sql, max_rows=self.max_rows + 1, timeout_s=self.timeout)
        rows = res.rows[: self.max_rows]
        if len(res.rows) > self.max_rows:
            notes.append(f"Showing the first {self.max_rows} rows.")

        tables = [anchor.fqn] + [t.fqn for _, t, _ in joins]
        base = dict(scope_label=scope_label, period_label=period_label, tables=tables, sql_rendered=sql, notes=notes,
                    meta={"spec": spec.model_dump(by_alias=True), "warehouse_ms": res.elapsed_ms})

        # ---- empty / not found
        if self._no_data(spec, out_cols, rows):
            if spec.identifiers:
                name, value = next(iter(spec.identifiers.items()))
                return QueryResult("not_found", code=f"{name}_not_found",
                                   message=f"No {name} '{value}' was found for {scope_label}"
                                           f"{' in ' + period_label if period_label else ''}.", **base)
            if spec.filters or spec.dimensions:
                return QueryResult("answer", columns=out_cols, rows=rows,
                                   message="No rows matched the requested filters.", **base)

        # ---- share only where meaningful (no negative parts)
        share_cols = [c for c in out_cols if c.endswith("_share_pct")]
        if share_cols:
            for sc in share_cols:
                src = sc[: -len("_share_pct")]
                i = out_cols.index(src)
                if any(isinstance(r[i], (int, float)) and r[i] < 0 for r in rows):
                    j = out_cols.index(sc)
                    out_cols = out_cols[:j] + out_cols[j + 1:]
                    rows = [r[:j] + r[j + 1:] for r in rows]
                    notes.append(f"Share of total not shown for {src} because it has negative values.")
        return QueryResult("answer", columns=out_cols, rows=rows, **base)

    # ================================================================== helpers
    def _plan_joins(self, anchor: Table, spec: QuerySpec, user: UserContext):
        """Place every referenced column; join only approved many-to-one recipes from the anchor."""
        spec = spec.model_copy(deep=True)
        joinable = {j.to_table: j for j in self.catalog.joins.values() if j.usable and j.from_table == anchor.name}
        needed: dict[str, JoinRecipe] = {}

        def place(column: str, table: str | None) -> str | None:
            if column == PERIOD_PSEUDO:
                return None
            if table:
                t = self.catalog.table(table)
                if not t:
                    raise CompileError("unknown_table", f"unknown table {table}")
                if t.name == anchor.name:
                    if not anchor.column(column):
                        raise CompileError("unknown_column", f"{anchor.name} has no column {column}")
                    return anchor.name
                if t.name not in joinable:
                    raise CompileError("join_unapproved", f"no approved join from {anchor.name} to {t.name}")
                if not t.column(column):
                    raise CompileError("unknown_column", f"{t.name} has no column {column}")
                needed[t.name] = joinable[t.name]
                return t.name
            if anchor.column(column):
                return anchor.name
            hits = [n for n in joinable if self.catalog.tables[n].column(column)]
            if len(hits) == 1:
                needed[hits[0]] = joinable[hits[0]]
                return hits[0]
            if len(hits) > 1:
                raise CompileError("ambiguous_column", f"column {column} exists in {hits}; set table")
            raise CompileError("unknown_column", f"column {column} is not in {anchor.name} or its approved joins "
                                                 f"({sorted(joinable)})")

        for m in spec.measures:
            if m.column:
                m.table = place(m.column, m.table)
        for d in spec.dimensions:
            d.table = place(d.column, d.table)
        for f in spec.filters:
            f.table = place(f.column, f.table)
        for name in spec.identifiers:
            b = anchor.identifiers.get(name)
            if b and b.table:
                if b.table not in joinable:
                    raise CompileError("join_unapproved", f"identifier {name} needs an approved join to {b.table}")
                needed[b.table] = joinable[b.table]
        joins = []
        for i, (tname, recipe) in enumerate(sorted(needed.items()), start=1):
            t = self.catalog.tables[tname]
            if t.domain not in (anchor.domain, "shared"):
                raise CompileError("cross_domain", f"{t.name} is in another domain")
            if not user.can_read_table(t.fqn):
                raise CompileError("table_access", f"no access to {t.name}")
            joins.append((recipe, t, f"d{i}"))
        return joins, spec

    def _resolve_entity(self, anchor: Table, domain, spec: QuerySpec, scopes, joins):
        if not anchor.entity_scope:
            return [], ""
        labels = self.lookup.entity_labels(domain.name, tuple(scopes))
        by_scope = {tuple(sorted(l.scope.items())): l for l in labels}

        def label_for(ss: list[dict[str, str]]) -> str:
            names = [by_scope[tuple(sorted(s.items()))].label for s in ss if tuple(sorted(s.items())) in by_scope]
            if not names:
                return "your authorized entities"
            if len(names) <= 3:
                return ", ".join(names)
            return f"{len(names)} authorized entities"

        if spec.entity_mention:
            hits = match_entities(spec.entity_mention, labels)
            if not hits:
                return QueryResult("not_found", code="entity_not_found",
                                   message=f"The entity '{spec.entity_mention}' was not found among your authorized "
                                           f"entities.", options=[l.label for l in labels][:10])
            if len(hits) > 1:
                return QueryResult("clarify", code="entity_ambiguous",
                                   message=f"'{spec.entity_mention}' matches more than one entity. Which one do you mean?",
                                   options=[h.label for h in hits][:10])
            ss = [hits[0].scope]
            return ss, label_for(ss)
        ent = domain.entity
        if ent and ent.required_when_multiple and len(scopes) > 1:
            if spec.identifiers:
                name, value = next(iter(spec.identifiers.items()))
                b = anchor.identifiers.get(name)
                if b:
                    join_on, tbl = None, anchor
                    if b.table:
                        recipe = next(r for r, t, _ in joins if t.name == b.table)
                        join_on, tbl = recipe.on, self.catalog.tables[b.table]
                    found = self.lookup.identifier_scopes(anchor, tbl, b.column, join_on, value, scopes)
                    if len(found) == 1:
                        return found, label_for(found)
                    if not found:
                        return QueryResult("not_found", code=f"{name}_not_found",
                                           message=f"No {name} '{value}' was found in your authorized entities.")
                    return QueryResult("clarify", code="entity_ambiguous",
                                       message=f"{name.title()} {value} exists in several entities. Which one do you mean?",
                                       options=[label_for([s]) for s in found])
            return QueryResult("clarify", code="entity_required", message="Which entity do you mean?",
                               options=[l.label for l in labels][:10])
        return scopes, label_for(scopes)

    def _resolve_period(self, anchor: Table, spec: QuerySpec, scopes, notes: list[str]):
        pb = anchor.period
        domain = self.catalog.domains[anchor.domain]
        if pb.mode == "none":
            if spec.period_mention and spec.period_policy not in ("all",):
                notes.append(f"This data has no period; '{spec.period_mention}' was not applied (current snapshot).")
            return None, "", spec
        ref = parse_period(spec.period_mention)
        policy = spec.period_policy
        if policy == "default":
            if ref and ref.kind in ("latest", "previous", "all"):
                policy = {"latest": "latest", "previous": "explicit", "all": "all"}[ref.kind]
            else:
                policy = "explicit" if spec.period_mention else domain.default_period_policy
        has_period_dim = any(d.column == PERIOD_PSEUDO for d in spec.dimensions)
        non_additive = [m for m in spec.measures if m.op in ("sum", "sum_abs", "avg") and m.column and
                        not (self.catalog.table(m.table or anchor.name).column(m.column).additive)]
        if policy == "all" and non_additive and not has_period_dim:
            policy = "latest"
            notes.append("Balances are point-in-time, so the latest period is used instead of adding periods together.")

        options = self.lookup.periods_with_data(anchor, scopes)
        if not options:
            return QueryResult("not_found", code="no_data", message="There is no data for this selection.")
        options = sorted(options, key=lambda o: (o.end or date.min, o.key))

        def pick_month(year: int, month: int) -> list[PeriodOption]:
            return [o for o in options if o.end and o.end.year == year and o.end.month == month]

        chosen: list[PeriodOption] = []
        if policy == "all":
            return None, "All periods", spec
        if policy == "latest":
            chosen = [options[-1]]
        elif policy in ("explicit", "compare_previous"):
            if ref and ref.kind == "previous":
                last = options[-1].end
                py, pm = (last.year, last.month - 1) if last.month > 1 else (last.year - 1, 12)
                chosen = pick_month(py, pm)
            elif ref and ref.kind == "month":
                chosen = pick_month(ref.year, ref.month)
            elif ref and ref.kind == "year":
                chosen = [o for o in options if o.end and o.end.year == ref.year]
            elif ref and ref.kind == "latest" or (policy == "compare_previous" and not spec.period_mention):
                chosen = [options[-1]]
            else:  # free text: match labels
                want = " ".join(norm_tokens(spec.period_mention))
                chosen = [o for o in options if " ".join(norm_tokens(o.label)) == want]
            if not chosen:
                avail = ", ".join(self._period_label(o, pb) for o in options[-6:])
                return QueryResult("not_found", code="period_not_found",
                                   message=f"The period '{spec.period_mention}' has no data. Available: {avail}.",
                                   options=[self._period_label(o, pb) for o in options[-6:]])
            if policy == "compare_previous":
                target = chosen[-1]
                py, pm = (target.end.year, target.end.month - 1) if target.end.month > 1 else (target.end.year - 1, 12)
                prev = pick_month(py, pm)
                if not prev:
                    return QueryResult("cannot_compare", code="previous_period_missing",
                                       message=f"There is no data for the period before {self._period_label(target, pb)}, "
                                               f"so no comparison is possible.")
                chosen = prev + [target]
                if not has_period_dim:
                    spec = spec.model_copy(deep=True)
                    spec.dimensions.insert(0, Dimension(column=PERIOD_PSEUDO))
        label = ", ".join(self._period_label(o, pb) for o in chosen)
        if pb.mode == "dimension":
            return PeriodFilter("dimension", ids=[str(o.key[0]) for o in chosen]), label, spec
        if pb.mode == "columns":
            return PeriodFilter("columns", pairs=[tuple(o.key) for o in chosen]), label, spec
        if pb.mode == "date":
            start = min(date(o.key[0], o.key[1], 1) for o in chosen)
            last = max(chosen, key=lambda o: o.key)
            end = date(last.key[0] + (last.key[1] == 12), last.key[1] % 12 + 1, 1)
            return PeriodFilter("date", start=start, end=end), label, spec
        return None, "", spec

    @staticmethod
    def _period_label(o: PeriodOption, pb) -> str:
        if pb.mode == "dimension" and o.label:
            return o.label
        if o.end:
            return o.end.strftime("%b %Y")
        return o.label

    @staticmethod
    def _no_data(spec: QuerySpec, cols: list[str], rows: list[list[Any]]) -> bool:
        if not rows:
            return True
        if spec.dimensions or spec.is_lookup:
            return False
        # single aggregate row: no data when every measure is NULL or every count is 0
        r = rows[0]
        vals = [r[cols.index(m.alias)] for m in spec.measures if m.alias in cols]
        return all(v is None or (v == 0 and m.op.startswith("count")) for v, m in zip(vals, spec.measures)) and bool(spec.identifiers)
