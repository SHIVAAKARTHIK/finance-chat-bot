"""Last check before execution: read-only, single SELECT, only allowed tables, bounded rows."""
from __future__ import annotations

import sqlglot
from sqlglot import exp

_FORBIDDEN = tuple(
    getattr(exp, n) for n in ("Insert", "Update", "Delete", "Drop", "Create", "Alter", "Merge", "Command",
                              "Grant", "TruncateTable", "Use", "Set", "Copy") if hasattr(exp, n)
)


def check_sql(sql: str, dialect: str, allowed_fqns: set[str], require_limit: bool = True) -> list[str]:
    problems: list[str] = []
    try:
        stmts = sqlglot.parse(sql, read=dialect)
    except sqlglot.errors.ParseError as e:  # pragma: no cover - our compiler output always parses
        return [f"unparseable SQL: {str(e)[:120]}"]
    stmts = [s for s in stmts if s is not None]
    if len(stmts) != 1:
        return ["exactly one statement is allowed"]
    root = stmts[0]
    if not isinstance(root, exp.Select):
        problems.append("only SELECT is allowed")
    for node in root.walk():
        if isinstance(node, _FORBIDDEN):
            problems.append(f"forbidden statement: {type(node).__name__}")
            break
    allowed = {a.lower() for a in allowed_fqns}
    cte_names = {c.alias_or_name.lower() for c in root.find_all(exp.CTE)}
    for t in root.find_all(exp.Table):
        name = ".".join(p for p in (t.catalog, t.db, t.name) if p).lower()
        if t.name.lower() in cte_names and not t.db:
            continue
        if name not in allowed:
            problems.append(f"table not allowed: {name}")
    if require_limit and isinstance(root, exp.Select) and not root.args.get("limit"):
        problems.append("missing LIMIT")
    return problems
