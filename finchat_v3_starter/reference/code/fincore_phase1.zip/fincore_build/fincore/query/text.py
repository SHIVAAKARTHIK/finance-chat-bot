"""Text helpers: period mentions and entity-name normalisation (no data access)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Literal

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}
MONTHS.update({"sept": 9, "january": 1, "february": 2, "march": 3, "april": 4, "june": 6, "july": 7,
               "august": 8, "september": 9, "october": 10, "november": 11, "december": 12})
MONTH_ABBR = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


@dataclass(frozen=True)
class PeriodRef:
    kind: Literal["month", "year", "latest", "previous", "all"]
    year: int | None = None
    month: int | None = None

    def month_start(self) -> date:
        assert self.year and self.month
        return date(self.year, self.month, 1)

    def month_end_exclusive(self) -> date:
        assert self.year and self.month
        return date(self.year + (self.month == 12), self.month % 12 + 1, 1)

    def label(self) -> str:
        if self.kind == "month":
            return f"{MONTH_ABBR[self.month]} {self.year}"
        if self.kind == "year":
            return str(self.year)
        return self.kind


def _year(y: str) -> int:
    n = int(y)
    return 2000 + n if n < 100 else n


def parse_period(text: str | None) -> PeriodRef | None:
    """'Feb 25', 'Feb 2025', 'February 2025', '2025-02', '02/2025', 'FY2026 P9', 'latest', 'last month'."""
    if not text:
        return None
    t = text.strip().lower()
    if re.search(r"\b(latest|current|most recent|this period)\b", t):
        return PeriodRef("latest")
    if re.search(r"\b(last|previous|prior) (month|period)\b", t):
        return PeriodRef("previous")
    if re.search(r"\b(all periods|all time|overall)\b", t):
        return PeriodRef("all")
    m = re.search(r"\bfy\s?(\d{2,4})\s*[- ]?\s*p(?:eriod)?\s?(\d{1,2})\b", t)
    if m:
        return PeriodRef("month", _year(m.group(1)), int(m.group(2)))
    m = re.search(r"\b(\d{4})-(\d{1,2})\b", t)
    if m and 1 <= int(m.group(2)) <= 12:
        return PeriodRef("month", int(m.group(1)), int(m.group(2)))
    m = re.search(r"\b(\d{1,2})/(\d{4})\b", t)
    if m and 1 <= int(m.group(1)) <= 12:
        return PeriodRef("month", int(m.group(2)), int(m.group(1)))
    m = re.search(r"\b([a-z]{3,9})[\s'’,-]*(\d{2}|\d{4})\b", t)
    if m and m.group(1) in MONTHS:
        return PeriodRef("month", _year(m.group(2)), MONTHS[m.group(1)])
    m = re.search(r"\b(?:fy\s?)?(20\d{2})\b", t)
    if m:
        return PeriodRef("year", int(m.group(1)))
    return None


_SUFFIXES = {"llc", "inc", "ltd", "limited", "plc", "gmbh", "co", "corp", "corporation", "company", "ag", "sa", "bv"}
_NOISE = {"entity", "legal", "company", "the", "for", "of", "subledger", "fynapse", "adra", "le"}


def norm_tokens(text: str | None) -> list[str]:
    toks = re.sub(r"[^a-z0-9]+", " ", (text or "").lower()).split()
    return [t for t in toks if t not in _SUFFIXES]


def mention_tokens(text: str | None) -> list[str]:
    return [t for t in norm_tokens(text) if t not in _NOISE]
