"""Small scoped lookups used during resolution: entity labels, periods with data, identifier
locations, grain uniqueness. All SQL is built with sqlglot and stays inside the user's scopes."""
from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any

import sqlglot
from sqlglot import exp

from ..exec.base import Executor
from ..semantic.catalog import Catalog
from ..semantic.models import Table
from . import sqlbuild as sb


@dataclass(frozen=True)
class EntityLabel:
    keys: tuple[tuple[str, str], ...]  # (scope key, value) pairs
    code: str
    name: str

    @property
    def scope(self) -> dict[str, str]:
        return dict(self.keys)

    @property
    def label(self) -> str:
        if self.code and self.name and self.code.lower() not in self.name.lower():
            return f"{self.code} - {self.name}"
        return self.name or self.code


@dataclass(frozen=True)
class PeriodOption:
    key: tuple[Any, ...]  # dimension: (id,), columns: (fy, p), date: (year, month)
    label: str
    end: date | None


def _as_date(v: Any) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        return None


class Lookup:
    def __init__(self, catalog: Catalog, executor: Executor, ttl_s: float = 300.0):
        self.catalog = catalog
        self.ex = executor
        self.ttl_s = ttl_s
        self._cache: dict[Any, tuple[float, Any]] = {}

    def _cached(self, key: Any, fn):
        hit = self._cache.get(key)
        now = time.monotonic()
        if hit and now - hit[0] < self.ttl_s:
            return hit[1]
        val = fn()
        self._cache[key] = (now, val)
        return val

    def clear(self) -> None:
        self._cache.clear()

    def _run(self, q: exp.Expression, max_rows: int = 5000) -> list[list[Any]]:
        return self.ex.execute(q.sql(dialect=self.ex.dialect), max_rows=max_rows).rows

    # ------------------------------------------------------------------ entities
    def entity_labels(self, domain: str, scopes: tuple[dict[str, str], ...]) -> list[EntityLabel]:
        dom = self.catalog.domains[domain]
        ent = dom.entity
        if not ent or not scopes:
            return []
        key = ("entities", domain, tuple(tuple(sorted(s.items())) for s in scopes))

        def load():
            if ent.label_table:
                t = self.catalog.tables[ent.label_table]
                cols = list(ent.keys.items())  # scope key -> label table column
                sel = [sb.typed("e", t.column(c)) for _, c in cols]
                sel.append(sb.typed("e", t.column(ent.code_column)) if ent.code_column else sb.lit(""))
                sel.append(sb.typed("e", t.column(ent.name_column)) if ent.name_column else sb.lit(""))
                q = sqlglot.select(*sel).distinct().from_(sb.table_ref(t.fqn, "e")).where(
                    sb.scope_predicate("e", dict(cols), list(scopes))).limit(5000)
                rows = self._run(q)
                keys = [k for k, _ in cols]
            else:  # no label table: distinct scope values from the domain's facts
                rows, keys = [], list(ent.keys)
                for t in self.catalog.tables.values():
                    if t.domain == domain and t.entity_scope and t.queryable:
                        sel = [sb.typed("f", t.column(t.entity_scope.columns[k])) for k in keys]
                        q = sqlglot.select(*sel, sb.lit(""), sb.lit("")).distinct().from_(sb.table_ref(t.fqn, "f")).where(
                            sb.scope_predicate("f", t.entity_scope.columns, list(scopes))).limit(5000)
                        rows += self._run(q)
            out = []
            for r in rows:
                kv = tuple((k, str(v).strip()) for k, v in zip(keys, r[: len(keys)]))
                code = str(r[len(keys)] or "").strip() or (kv[-1][1] if kv else "")
                out.append(EntityLabel(kv, code, str(r[len(keys) + 1] or "").strip()))
            return sorted(set(out), key=lambda e: e.label)

        return self._cached(key, load)

    # ------------------------------------------------------------------ periods
    def periods_with_data(self, table: Table, scopes: list[dict[str, str]]) -> list[PeriodOption]:
        pb = table.period
        key = ("periods", table.name, tuple(tuple(sorted(s.items())) for s in scopes))

        def load():
            scope = sb.scope_predicate("f", table.entity_scope.columns, scopes) if table.entity_scope else None
            if pb.mode == "dimension":
                pt = self.catalog.tables[pb.table]
                ids_q = sqlglot.select(exp.Trim(this=exp.cast(sb.col("f", pb.id_column), "VARCHAR"))).distinct().from_(
                    sb.table_ref(table.fqn, "f"))
                if scope is not None:
                    ids_q = ids_q.where(scope)
                label = sb.typed("p", pt.column(pb.label_column)) if pb.label_column else sb.lit("")
                pscope = None
                if pb.dim_scope_columns:
                    pscope = sb.scope_predicate("p", pb.dim_scope_columns, scopes)
                where = exp.In(this=exp.Trim(this=exp.cast(sb.col("p", pb.dim_id_column), "VARCHAR")),
                               query=ids_q.subquery())
                q = sqlglot.select(exp.Trim(this=exp.cast(sb.col("p", pb.dim_id_column), "VARCHAR")), label,
                                   sb.typed("p", pt.column(pb.date_column))).distinct().from_(
                    sb.table_ref(pt.fqn, "p")).where(sb.and_all([where, pscope])).limit(5000)
                return [PeriodOption((str(r[0]),), str(r[1] or "").strip(), _as_date(r[2])) for r in self._run(q)]
            if pb.mode == "columns":
                sel = [sb.typed("f", table.column(c)) for c in pb.columns]
                d = sb.typed("f", table.column(pb.date_column))
                q = sqlglot.select(*sel, exp.Max(this=d)).from_(sb.table_ref(table.fqn, "f"))
                if scope is not None:
                    q = q.where(scope)
                q = q.group_by(*sel).limit(5000)
                out = []
                for r in self._run(q):
                    end = _as_date(r[-1])
                    vals = tuple(int(v) for v in r[: len(pb.columns)])
                    out.append(PeriodOption(vals, f"FY{vals[0]} P{vals[1]}" if len(vals) == 2 else str(vals), end))
                return out
            if pb.mode == "date":
                d = exp.cast(sb.typed("f", table.column(pb.date_column)), "DATE")
                m = exp.cast(exp.func("date_trunc", sb.lit("month"), d), "DATE")
                q = sqlglot.select(m).distinct().from_(sb.table_ref(table.fqn, "f"))
                if scope is not None:
                    q = q.where(scope)
                out = []
                for (v,) in self._run(q.limit(5000)):
                    dd = _as_date(v)
                    if dd:
                        out.append(PeriodOption((dd.year, dd.month), dd.strftime("%b %Y"), dd))
                return out
            return []

        return self._cached(key, load)

    # ------------------------------------------------------------------ identifiers
    def identifier_scopes(self, table: Table, ident_alias_table: Table, ident_col: str, join_on, value: str,
                          scopes: list[dict[str, str]]) -> list[dict[str, str]]:
        """Which authorized scopes contain this identifier value (e.g. account 103300)."""
        if not table.entity_scope:
            return list(scopes)
        keys = list(table.entity_scope.columns)
        sel = [exp.Trim(this=exp.cast(sb.col("f", table.entity_scope.columns[k]), "VARCHAR")) for k in keys]
        q = sqlglot.select(*sel).distinct().from_(sb.table_ref(table.fqn, "f"))
        alias = "f"
        if join_on:
            q = q.join(sb.table_ref(ident_alias_table.fqn, "d"),
                       on=sb.and_all([exp.EQ(this=sb.col("f", l), expression=sb.col("d", r)) for l, r in join_on]),
                       join_type="inner")
            alias = "d"
        q = q.where(sb.and_all([sb.scope_predicate("f", table.entity_scope.columns, scopes),
                                sb.text_eq(sb.typed(alias, ident_alias_table.column(ident_col)), value)])).limit(500)
        return [dict(zip(keys, (str(v) for v in r))) for r in self._run(q)]

    # ------------------------------------------------------------------ data quality
    def grain_duplicates(self, table: Table, scopes: list[dict[str, str]], columns: list[str] | None = None) -> int:
        """Rows minus distinct grain rows inside the scopes (0 = unique)."""
        cols = columns or table.grain
        if not cols:
            return 0
        key = ("grain", table.name, tuple(cols), tuple(tuple(sorted(s.items())) for s in scopes))

        def load():
            scope = sb.scope_predicate("f", table.entity_scope.columns, scopes) if table.entity_scope else None
            src = sb.table_ref(table.fqn, "f")
            if table.current_row_rule:
                from .compiler import Compiler, ResolvedQuery  # reuse the same de-dup subquery
                from .spec import QuerySpec
                dummy = ResolvedQuery(QuerySpec(anchor=table.name, measures=[{"op": "count_rows"}]), table, scopes,
                                      None, [], [], True)
                src = Compiler(dummy)._anchor_source()
            n = sqlglot.select(exp.Count(this=exp.Star())).from_(src.copy())
            d = sqlglot.select(*[sb.col("f", c) for c in cols]).distinct().from_(src.copy())
            if scope is not None:
                n, d = n.where(scope), d.where(scope.copy())
            q = sqlglot.select(exp.alias_(n.subquery(), "n"),
                               exp.alias_(sqlglot.select(exp.Count(this=exp.Star())).from_(d.subquery("x")).subquery(), "d"))
            r = self._run(q.limit(1))[0]
            return int(r[0] or 0) - int(r[1] or 0)

        return self._cached(key, load)
