"""Databricks SQL executor (databricks-sql-connector). Connection settings come from the host.

Keeps one warm connection per process (the first statement on a new connection can take 10+ s).
Call `warm_up()` at application start.
"""
from __future__ import annotations

import threading
import time
from decimal import Decimal
from typing import Any, Callable

from .base import ExecResult, ExecutionError


class DatabricksExecutor:
    dialect = "databricks"

    def __init__(self, connect: Callable[[], Any]):
        """connect: zero-arg callable returning a DB-API connection, e.g.
        lambda: databricks.sql.connect(server_hostname=..., http_path=..., credentials_provider=...)
        Credentials stay in the host; this class never reads env vars or secrets."""
        self._connect = connect
        self._con = None
        self._lock = threading.Lock()

    def _connection(self):
        with self._lock:
            if self._con is None:
                self._con = self._connect()
            return self._con

    def warm_up(self) -> None:
        try:
            self.execute("SELECT 1", max_rows=1, timeout_s=30)
        except ExecutionError:
            pass

    def execute(self, sql: str, max_rows: int = 500, timeout_s: float = 30.0) -> ExecResult:
        t0 = time.perf_counter()
        try:
            con = self._connection()
            with con.cursor() as cur:
                cur.execute(sql)
                cols = [d[0] for d in cur.description]
                rows = [[(float(v) if isinstance(v, Decimal) else v) for v in r] for r in cur.fetchmany(max_rows)]
                qid = getattr(cur, "query_id", None)
        except Exception as e:
            msg = str(e)
            with self._lock:  # drop a broken connection so the next call reconnects
                self._con = None
            raise ExecutionError(f"{type(e).__name__}: {msg[:300]}", timeout="timeout" in msg.lower()) from e
        elapsed = (time.perf_counter() - t0) * 1000
        if elapsed > timeout_s * 1000:
            raise ExecutionError(f"query exceeded {timeout_s}s", timeout=True)
        return ExecResult(cols, rows, round(elapsed, 1), qid)
