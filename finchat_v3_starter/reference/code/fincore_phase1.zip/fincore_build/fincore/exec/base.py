"""Executor protocol: runs read-only SQL and returns columns + rows."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass
class ExecResult:
    columns: list[str]
    rows: list[list[Any]]
    elapsed_ms: float = 0.0
    query_id: str | None = None


class ExecutionError(RuntimeError):
    def __init__(self, message: str, timeout: bool = False):
        super().__init__(message)
        self.timeout = timeout


class Executor(Protocol):
    dialect: str

    def execute(self, sql: str, max_rows: int = 500, timeout_s: float = 30.0) -> ExecResult: ...
