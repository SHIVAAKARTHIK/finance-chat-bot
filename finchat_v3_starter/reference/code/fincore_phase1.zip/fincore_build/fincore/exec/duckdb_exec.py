"""DuckDB executor for local tests. Tables live under the same catalog.schema names as Databricks."""
from __future__ import annotations

import time
from decimal import Decimal

from .base import ExecResult, ExecutionError


class DuckDBExecutor:
    dialect = "duckdb"

    def __init__(self, path: str = ":memory:", con=None):
        import duckdb  # lazy

        self.con = con or duckdb.connect(path)

    def execute(self, sql: str, max_rows: int = 500, timeout_s: float = 30.0) -> ExecResult:
        t0 = time.perf_counter()
        try:
            cur = self.con.execute(sql)
            cols = [d[0] for d in cur.description]
            rows = [[(float(v) if isinstance(v, Decimal) else v) for v in r] for r in cur.fetchmany(max_rows)]
        except Exception as e:  # surface a clean, sanitised message
            raise ExecutionError(f"{type(e).__name__}: {str(e)[:300]}") from e
        return ExecResult(cols, rows, round((time.perf_counter() - t0) * 1000, 1))
