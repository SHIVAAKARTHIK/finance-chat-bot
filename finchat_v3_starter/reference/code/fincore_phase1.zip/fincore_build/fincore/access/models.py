"""Access model: who may query which tables, for which entities, and whether PII is visible.

The access provider is pluggable: YAML now (YamlAccessProvider), an entitlement table or Entra
groups later. The engine only sees `UserContext`, built by the host from the authenticated request.
"""
from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

import yaml


@dataclass(frozen=True)
class UserContext:
    user_id: str
    roles: tuple[str, ...]
    tables: tuple[str, ...]  # fqn patterns, e.g. "lakehouse_mvpai.silver.*"
    domains: tuple[str, ...]  # domain names or "*"
    domain_scopes: dict[str, tuple[dict[str, str], ...]] = field(default_factory=dict)
    can_view_pii: bool = False

    def can_read_table(self, fqn: str) -> bool:
        return any(fnmatch.fnmatch(fqn.lower(), p.lower()) for p in self.tables)

    def can_use_domain(self, domain: str) -> bool:
        return "*" in self.domains or domain in self.domains

    def scopes_for(self, domain: str) -> tuple[dict[str, str], ...]:
        return self.domain_scopes.get(domain, ())


class AccessProvider(Protocol):
    def user_context(self, user_id: str, groups: list[str] | None = None) -> UserContext | None: ...


class YamlAccessProvider:
    """roles: {name: {tables, domains, domain_scopes, can_view_pii}}, users: {id: role}, group_roles: {group: role}.

    Legacy ADRA `allowed_entity_scopes` is accepted and mapped to the given legacy domains.
    """

    def __init__(self, path: str | Path, legacy_scope_domains: tuple[str, ...] = ("adra", "close")):
        self.doc = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        self.legacy_scope_domains = legacy_scope_domains

    def _role_context(self, user_id: str, role_names: list[str]) -> UserContext | None:
        roles = self.doc.get("roles", {})
        tables: list[str] = []
        domains: list[str] = []
        scopes: dict[str, list[dict[str, str]]] = {}
        pii = False
        found = []
        for rn in role_names:
            r = roles.get(rn)
            if not r:
                continue
            found.append(rn)
            tables += r.get("tables", [])
            domains += r.get("domains", [])
            pii = pii or bool(r.get("can_view_pii", False))
            for dom, lst in (r.get("domain_scopes") or {}).items():
                scopes.setdefault(dom, []).extend({k: str(v) for k, v in s.items()} for s in lst)
            for s in r.get("allowed_entity_scopes") or []:
                norm = {k.upper(): str(v) for k, v in s.items()}
                for dom in self.legacy_scope_domains:
                    scopes.setdefault(dom, []).append(norm)
        if not found:
            return None
        dedup = {d: tuple({tuple(sorted(s.items())): s for s in lst}.values()) for d, lst in scopes.items()}
        return UserContext(user_id=user_id, roles=tuple(found), tables=tuple(tables), domains=tuple(domains),
                           domain_scopes=dedup, can_view_pii=pii)

    def user_context(self, user_id: str, groups: list[str] | None = None) -> UserContext | None:
        users = self.doc.get("users", {}) or {}
        if user_id in users:
            r = users[user_id]
            return self._role_context(user_id, r if isinstance(r, list) else [r])
        gr = self.doc.get("group_roles", {}) or {}
        role_names = [gr[g] for g in (groups or []) if g in gr]
        if role_names:
            return self._role_context(user_id, role_names)
        default = self.doc.get("default_role")
        return self._role_context(user_id, [default]) if default else None
