"""Load and query the semantic catalog (config/semantic/*.yaml)."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

import yaml

from .models import Domain, JoinRecipe, Table


class CatalogError(ValueError):
    pass


class Catalog:
    def __init__(self, domains: Iterable[Domain], tables: Iterable[Table], joins: Iterable[JoinRecipe],
                 rules: dict[str, str] | None = None):
        self.domains = {d.name: d for d in domains}
        self.tables = {t.name: t for t in tables}
        self.joins = {j.id: j for j in joins}
        self.rules = rules or {}
        self._validate()

    # ------------------------------------------------------------------ loading
    @classmethod
    def load(cls, root: str | Path) -> "Catalog":
        root = Path(root)
        sem = root / "semantic" if (root / "semantic").is_dir() else root
        doms = yaml.safe_load((sem / "domains.yaml").read_text(encoding="utf-8")) or {}
        domains = [Domain(name=n, **(v or {})) for n, v in (doms.get("domains") or {}).items()]
        tables: list[Table] = []
        for p in sorted((sem / "tables").glob("*.yaml")):
            doc = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            for t in doc.get("tables", []):
                tables.append(Table(**t))
        jdoc = yaml.safe_load((sem / "joins.yaml").read_text(encoding="utf-8")) if (sem / "joins.yaml").exists() else {}
        joins = []
        for j in (jdoc or {}).get("joins", []):
            if True in j:  # YAML 1.1 reads the key `on` as boolean True
                j["on"] = j.pop(True)
            joins.append(JoinRecipe(**j))
        rules = {}
        for d in domains:
            if d.rules_file:
                rp = (root / d.rules_file) if (root / d.rules_file).exists() else (sem.parent / d.rules_file)
                if rp.exists():
                    rules[d.name] = rp.read_text(encoding="utf-8")
        return cls(domains, tables, joins, rules)

    def _validate(self) -> None:
        for t in self.tables.values():
            if t.domain not in self.domains:
                raise CatalogError(f"table {t.name}: unknown domain {t.domain}")
            if t.period.mode == "dimension" and t.period.table not in self.tables:
                raise CatalogError(f"table {t.name}: period table {t.period.table} not in catalog")
            for ident, b in t.identifiers.items():
                if b.table and b.table not in self.tables:
                    raise CatalogError(f"table {t.name}: identifier {ident} table {b.table} not in catalog")
            if t.entity_scope:
                dom = self.domains[t.domain]
                if not dom.entity:
                    raise CatalogError(f"table {t.name}: entity_scope but domain {t.domain} has no entity")
                missing = set(dom.entity.keys) - set(t.entity_scope.columns)
                if missing:
                    raise CatalogError(f"table {t.name}: entity_scope missing keys {sorted(missing)}")
        for j in self.joins.values():
            for side in (j.from_table, j.to_table):
                if side not in self.tables:
                    raise CatalogError(f"join {j.id}: unknown table {side}")
            for a, b in j.on:
                if not self.tables[j.from_table].column(a) or not self.tables[j.to_table].column(b):
                    raise CatalogError(f"join {j.id}: unknown column in {a}={b}")

    # ------------------------------------------------------------------ queries
    def table(self, name: str) -> Table | None:
        if name in self.tables:
            return self.tables[name]
        short = name.split(".")[-1].lower()
        for t in self.tables.values():
            if t.name.lower() == short or t.fqn.lower() == name.lower():
                return t
        return None

    def enabled_domains(self) -> set[str]:
        return {d.name for d in self.domains.values() if d.enabled}

    def join_between(self, from_table: str, to_table: str) -> JoinRecipe | None:
        for j in self.joins.values():
            if j.usable and j.from_table == from_table and j.to_table == to_table:
                return j
        return None

    def domains_named_in(self, text: str) -> set[str]:
        """Domains whose keywords appear in the text (word match, case-insensitive)."""
        low = f" {re.sub(r'[^a-z0-9]+', ' ', (text or '').lower())} "
        hit = set()
        for d in self.domains.values():
            for kw in d.keywords:
                k = re.sub(r"[^a-z0-9]+", " ", kw.lower()).strip()
                if k and f" {k} " in low:
                    hit.add(d.name)
        return hit
