"""Semantic metadata: domains, tables, columns, joins, bindings.

Everything the engine knows about the data comes from these models, loaded from YAML
(config/semantic). No table-specific logic lives in code.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

LogicalType = Literal["string", "decimal", "integer", "date", "timestamp", "boolean"]
ColumnRole = Literal["identifier", "measure", "dimension", "label", "date", "flag", "text", "key", "audit"]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Column(Strict):
    name: str
    type: LogicalType = "string"  # logical type used by the engine
    physical: LogicalType = "string"  # storage type; casts are applied when physical != type
    role: ColumnRole = "dimension"
    description: str = ""
    synonyms: list[str] = Field(default_factory=list)
    values: list[str] = Field(default_factory=list)  # known categorical values (trimmed)
    pii: bool = False
    additive: bool = True  # False for snapshot balances: never summed across periods


class EntityScopeBinding(Strict):
    """Maps the domain's scope keys to this table's columns, e.g. {DATA_AREA_ID: ENTITY_ID}."""

    columns: dict[str, str]


class PeriodBinding(Strict):
    mode: Literal["none", "dimension", "columns", "date"] = "none"
    # dimension mode: fact.<id_column> joins <table>.<dim_id_column>; label/date read from the dimension
    table: str | None = None
    id_column: str | None = None
    dim_id_column: str | None = None
    dim_scope_columns: dict[str, str] = Field(default_factory=dict)  # domain scope key -> dim column
    label_column: str | None = None
    date_column: str | None = None  # dimension: period end date; columns/date: fact date column
    # columns mode: e.g. [FISCAL_YEAR, PERIOD]
    columns: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check(self) -> "PeriodBinding":
        if self.mode == "dimension" and not (self.table and self.id_column and self.dim_id_column and self.date_column):
            raise ValueError("dimension period binding needs table, id_column, dim_id_column, date_column")
        if self.mode == "columns" and not (self.columns and self.date_column):
            raise ValueError("columns period binding needs columns and date_column")
        if self.mode == "date" and not self.date_column:
            raise ValueError("date period binding needs date_column")
        return self


class IdentifierBinding(Strict):
    """How a business identifier (account, asset ...) mentioned in a question is matched."""

    column: str
    table: str | None = None  # None = on the table itself; otherwise a dimension reached by an approved join


class CurrentRowRule(Strict):
    """Optional de-duplication when the source holds several versions per grain."""

    partition_by: list[str]
    order_by: str
    descending: bool = True


class Table(Strict):
    name: str  # short name used in specs
    fqn: str  # fully qualified, e.g. lakehouse_mvpai.silver.adra_account_facts
    domain: str
    role: Literal["fact", "dim"]
    description: str = ""
    synonyms: list[str] = Field(default_factory=list)
    grain: list[str] = Field(default_factory=list)
    grain_noun: str = "rows"  # "how many <grain_noun>" -> count of rows
    columns: dict[str, Column]
    entity_scope: EntityScopeBinding | None = None
    period: PeriodBinding = Field(default_factory=PeriodBinding)
    identifiers: dict[str, IdentifierBinding] = Field(default_factory=dict)
    current_row_rule: CurrentRowRule | None = None
    grain_check: bool = True  # verify uniqueness at the grain before answering
    queryable: bool = True  # False = label/reference only

    @model_validator(mode="before")
    @classmethod
    def _columns_from_list(cls, data):
        cols = data.get("columns") if isinstance(data, dict) else None
        if isinstance(cols, list):
            data = dict(data)
            data["columns"] = {c["name"]: c for c in cols}
        return data

    @model_validator(mode="after")
    def _check(self) -> "Table":
        for g in self.grain:
            if g not in self.columns:
                raise ValueError(f"{self.name}: grain column {g} not in columns")
        if self.entity_scope:
            for col in self.entity_scope.columns.values():
                if col not in self.columns:
                    raise ValueError(f"{self.name}: scope column {col} not in columns")
        return self

    def column(self, name: str) -> Column | None:
        if name in self.columns:
            return self.columns[name]
        low = name.lower()
        for c in self.columns.values():
            if c.name.lower() == low:
                return c
        return None


class EntityDefinition(Strict):
    label_table: str | None = None  # table holding entity codes/names
    keys: dict[str, str]  # domain scope key -> column in label_table (or the fact if no label table)
    code_column: str | None = None
    name_column: str | None = None
    required_when_multiple: bool = False  # ask "which entity?" when several are authorized


class Domain(Strict):
    name: str
    title: str = ""
    enabled: bool = True
    keywords: list[str] = Field(default_factory=list)
    entity: EntityDefinition | None = None
    default_period_policy: Literal["latest", "all"] = "all"
    rules_file: str | None = None


class JoinRecipe(Strict):
    id: str
    from_table: str = Field(alias="from")
    to_table: str = Field(alias="to")
    on: list[tuple[str, str]]
    cardinality: Literal["many_to_one", "one_to_one", "one_to_many", "many_to_many"]
    status: Literal["approved", "blocked", "proposed"] = "proposed"
    note: str = ""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    @property
    def usable(self) -> bool:
        return self.status == "approved" and self.cardinality in ("many_to_one", "one_to_one")
