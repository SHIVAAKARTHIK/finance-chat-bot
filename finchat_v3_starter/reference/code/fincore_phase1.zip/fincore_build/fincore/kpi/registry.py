"""KPI registry: governed metrics defined in YAML and executed by the same SemanticEngine.

A KPI is a reviewed QuerySpec template plus optional derived values (safe arithmetic over the
result columns, e.g. a percentage). The question only supplies entity/period/grouping; the measure
logic is fixed, so a KPI answer is "Governed" rather than "Unverified".
"""
from __future__ import annotations

import ast
import operator
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field

from ..access.models import UserContext
from ..query.engine import SemanticEngine
from ..query.result import QueryResult
from ..query.text import norm_tokens

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.USub: operator.neg}


def safe_eval(expr: str, values: dict[str, Any]) -> float | None:
    """Arithmetic over named result columns only (+ - * / and numbers). Division by zero -> None."""
    tree = ast.parse(expr, mode="eval")

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return float(n.value)
        if isinstance(n, ast.Name):
            v = values.get(n.id)
            if v is None:
                raise ZeroDivisionError
            return float(v)
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError(f"unsupported expression element: {ast.dump(n)}")

    try:
        return ev(tree)
    except ZeroDivisionError:
        return None


class Derived(BaseModel):
    model_config = ConfigDict(extra="forbid")
    alias: str
    expr: str
    round: int | None = None


class KpiDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    name: str
    domain: str
    description: str = ""
    status: str = "draft"  # draft | validated | deprecated
    owner: str = ""
    synonyms: list[str] = Field(default_factory=list)
    spec: dict[str, Any]
    derived: list[Derived] = Field(default_factory=list)
    allow_dimensions: list[str] = Field(default_factory=list)  # extra group-bys the question may add


@dataclass
class KpiMatch:
    kpi: KpiDefinition
    score: float


class KpiRegistry:
    def __init__(self, kpis: list[KpiDefinition], engine: SemanticEngine):
        self.kpis = {k.id: k for k in kpis}
        self.engine = engine

    @classmethod
    def load(cls, folder: str | Path, engine: SemanticEngine) -> "KpiRegistry":
        kpis: list[KpiDefinition] = []
        for p in sorted(Path(folder).glob("*.yaml")):
            for k in (yaml.safe_load(p.read_text(encoding="utf-8")) or {}).get("kpis", []):
                kpis.append(KpiDefinition(**k))
        return cls(kpis, engine)

    def find(self, question: str, user: UserContext, limit: int = 5, min_score: float = 0.5) -> list[KpiMatch]:
        q = set(norm_tokens(question))
        out = []
        for k in self.kpis.values():
            if k.status == "deprecated" or not user.can_use_domain(k.domain):
                continue
            best = 0.0
            for phrase in [k.name, *k.synonyms]:
                toks = set(norm_tokens(phrase))
                if toks:
                    best = max(best, len(toks & q) / len(toks))
            if best >= min_score:
                out.append(KpiMatch(k, round(best, 3)))
        return sorted(out, key=lambda m: -m.score)[:limit]

    def run(self, kpi_id: str, user: UserContext, entity_mention: str | None = None,
            period_mention: str | None = None, period_policy: str = "default",
            dimensions: list[str] | None = None, identifiers: dict[str, str] | None = None) -> QueryResult:
        k = self.kpis.get(kpi_id)
        if not k:
            return QueryResult("invalid_spec", code="unknown_kpi", message=f"Unknown KPI {kpi_id}.")
        spec = dict(k.spec)
        spec["entity_mention"] = entity_mention
        spec["period_mention"] = period_mention
        spec["period_policy"] = period_policy
        if identifiers:
            spec["identifiers"] = identifiers
        for d in dimensions or []:
            if d not in k.allow_dimensions:
                return QueryResult("invalid_spec", code="dimension_not_allowed",
                                   message=f"KPI {k.name} cannot be split by {d}.",
                                   errors=[f"allowed: {k.allow_dimensions}"])
            spec.setdefault("dimensions", []).append({"column": d})
        res = self.engine.run(spec, user)
        res.source = "kpi"
        res.meta["kpi_id"] = k.id
        res.meta["kpi_status"] = k.status
        if res.kind == "answer" and k.derived:
            cols = list(res.columns)
            new_rows = []
            for row in res.rows:
                vals = dict(zip(cols, row))
                extra = []
                for d in k.derived:
                    v = safe_eval(d.expr, vals)
                    extra.append(round(v, d.round) if v is not None and d.round is not None else v)
                    vals[d.alias] = extra[-1]
                new_rows.append(list(row) + extra)
            res.columns = cols + [d.alias for d in k.derived]
            res.rows = new_rows
        return res
