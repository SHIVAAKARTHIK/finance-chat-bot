# Fixed asset rules
- Asset counts and invested capital come from dim_fixed_asset_books (ACQUISITION_PRICE).
- "Not financially activated" = STATUS NoAcquisition (acquisition price 0).
- "Inactive" assets = STATUS Sold, Scrapped or Closed.
- Asset category = FIXED_ASSET_GROUP_ID.
- Transaction workload comes from fact_asset_master_transactions by TRANSACTION_TYPE.
- Known data issue: source tables currently hold duplicate loads; answers are withheld until resolved.
