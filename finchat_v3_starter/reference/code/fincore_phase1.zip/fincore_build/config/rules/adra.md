# ADRA business rules
- "Pending closure", "unfinished", "open" reconciliation = IS_FINALIZED is false.
- "Finalized", "closed", "completed" reconciliation = IS_FINALIZED is true.
- Reconciliation status words map to ACCOUNT_STATUS values: Not prepared, Prepared, Approved, Approval not needed.
- "Unreconciled difference" = UNIDENTIFIED_BALANCE (use UNIDENTIFIED_BALANCE_ABS for "largest" or "total absolute").
- Balances are point-in-time per period: never add balances across periods.
- "How many accounts" = count of account-period rows in the selected period.
- Transactions: TRANSACTION_TYPE (Ledger / Subledger) is not TRANSACTION_STATUS.
- Open questions for the business (do not guess): "pending with <person>", "unfinished tasks", task periods.
