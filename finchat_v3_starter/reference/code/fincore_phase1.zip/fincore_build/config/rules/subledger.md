# Fynapse subledger rules
- One row = one journal line. "How many lines" = count of rows; "how many journals" = distinct JOURNAL_ID.
- Entity = PARENT_ENTITY (UK03, UK06, ...). CHILD_ENTITY is a sub-unit, often empty.
- Period = FISCAL_YEAR + PERIOD; CORE_DATE gives the calendar month (P8 = Aug 2026, P9 = Sep 2026).
- "Net" or "balanced" = SUM(REPORTING_AMOUNT); a balanced subledger nets to (almost) zero.
- "Gross" = sum of absolute amounts.
- Source system: NOVIDEA, ACCRUAL, Concur.
